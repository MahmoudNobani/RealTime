#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <unistd.h>
#include <time.h>
#include "local.h"
int *var,*extra;
int prev=0,prev1=0;
key_t ipc_key;
//gcc -g openGL.c -o openGL -lglut -lGLU -lGL -lm
int choco[3]={0,0,0};
int choco_cont[3]={0,0,0};
int choco_cartons[3]={0,0,0};
int truck[3]={0,0,0};
int p=0,s=0;


//function for the produced chocolates
void clear_chocoA(int n){
    int m=0;
    float x;
    for(float i = -0.65; i > -1.0; i-=0.05){//x
        for(float j = 0.85; j > 0.3 ; j-=0.05){//y
            if(m>=n){
                return;
            }
            glPointSize(5.0f);
            glBegin(GL_POINTS);
            glColor3f(0.0f, 0.0f, 0.0f); // black
            glVertex2f(i, j); //x,y
            glEnd();
            m++;
            
        }
    }
}

void add_to_chocoA(int n){
    clear_chocoA(choco[0]);
    int k = var[21];
    int m=0;
    float x;
    for(float i = -0.65; i > -1.0; i-=0.05){//x
        for(float j = 0.85; j > 0.3 ; j-=0.05){//y
            if(m>=n){
                choco[0]=m;
                return;
            }
            glPointSize(5.0f);
            glBegin(GL_POINTS);
            if (k == 0){
                glColor3f(0.0f, 1.0f, 0.0f); //green
            }
            else{
                glColor3f(1.0f, 0.0f, 0.0f); //red
            }
            glVertex2f(i, j); //x,y
            glEnd();
            m++;
            
        }
    }
}

void clear_chocoB(int n){
    int m=0;
    float x;
    for(float i = -0.65; i > -1.0; i-=0.05){//x
        for(float j = 0.25; j > -0.25 ; j-=0.05){//y
            if(m>=n){
                return;
            }
            glPointSize(5.0f);
            glBegin(GL_POINTS);
            glColor3f(0.0f, 0.0f, 0.0f); // black
            glVertex2f(i, j); //x,y
            glEnd();
            m++;
        }
    }
}

void add_to_chocoB(int n){
    clear_chocoB(choco[1]);
    int k = var[21];
    int m=0;
    float x;
    for(float i = -0.65; i > -1.0; i-=0.05){//x
        for(float j = 0.25; j > -0.25 ; j-=0.05){//y
            if(m>=n){
                choco[1]=m;
                return;
            }
            glPointSize(5.0f);
            glBegin(GL_POINTS);
            if (k == 0){
                glColor3f(0.0f, 0.0f, 1.0f); //blue
            }
            else{
                glColor3f(1.0f, 0.0f, 0.0f); //red
            }
            glVertex2f(i, j); //x,y
            glEnd();
            m++;
        }
    }
}

void clear_chocoC(int n){
    int m=0;
    float x;
    for(float i = -0.65; i > -1.0; i-=0.05){//x
        for(float j = -0.35; j > -0.9 ; j-=0.05){//y
            if(m>=n){
                return;
            }
            glPointSize(5.0f);
            glBegin(GL_POINTS);
            glColor3f(0.0f, 0.0f, 0.0f); // black
            glVertex2f(i, j); //x,y
            glEnd();
            m++;

        }
    }
}

void add_to_chocoC(int n){
    clear_chocoC(choco[2]);
    int k = var[21];
    int m=0;
    float x;
    for(float i = -0.65; i > -1.0; i-=0.05){//x
        for(float j = -0.35; j > -0.9; j-=0.05){//y
            if(m>=n){
                choco[2]=m;
                return;
            }
            glPointSize(5.0f);
            glBegin(GL_POINTS);
            if (k == 0){
                glColor3f(1.0f, 1.0f, 0.0f);  //yellow
            }
            else{
                glColor3f(1.0f, 0.0f, 0.0f); //red
            }
            glVertex2f(i, j); //x,y
            glEnd();
            m++;
        }
    }
}


//function for the chocolate after being put in containers
void clear_chocoA_containers(int n){
    int m=0;
    float x;
    for(float i = 0.15; i > -0.2; i-=0.05){//x
        for(float j = 0.85; j > 0.3 ; j-=0.05){//y
            if(m>=n){
                return;
            }
            glPointSize(5.0f);
            glBegin(GL_POINTS);
            glColor3f(0.0f, 0.0f, 0.0f); // black
            glVertex2f(i, j); //x,y
            glEnd();
            m++;
        }
    }
}

void add_to_chocoA_containers(int n){
    clear_chocoA_containers(choco_cont[0]);
    int k = 1;
    int m=0;
    float x;
    for(float i = 0.15; i > -0.2; i-=0.05){//x
        for(float j = 0.85; j > 0.3 ; j-=0.05){//y
            if(m>=n){
                choco_cont[0]=m;
                return;
            }
            glPointSize(5.0f);
            glBegin(GL_POINTS);
            if (k == 1){
                glColor3f(0.0f, 1.0f, 0.0f); //green
            }
            else{
                glColor3f(1.0f, 0.0f, 0.0f); //red
            }
            glVertex2f(i, j); //x,y
            glEnd();
            m++;
            
        }
    }
}

void clear_chocoB_containers(int n){
    int m=0;
    float x;
    for(float i = 0.15; i > -0.2; i-=0.05){//x
        for(float j = 0.25; j > -0.25 ; j-=0.05){//y
            if(m>=n){
                return;
            }
            glPointSize(5.0f);
            glBegin(GL_POINTS);
            glColor3f(0.0f, 0.0f, 0.0f); // black
            glVertex2f(i, j); //x,y
            glEnd();
            m++;
            
        }
    }
}

void add_to_chocoB_containers(int n){
    clear_chocoB_containers(choco_cont[1]);
    int k = 1;
    int m=0;
    float x;
    for(float i = 0.15; i > -0.2; i-=0.05){//x
        for(float j = 0.25; j > -0.25 ; j-=0.05){//y
            if(m>=n){
                choco_cont[1]=m;
                return;
            }
            glPointSize(5.0f);
            glBegin(GL_POINTS);
            if (k == 1){
                glColor3f(0.0f, 0.0f, 1.0f); //blue
            }
            else{
                glColor3f(1.0f, 0.0f, 0.0f); //red
            }
            glVertex2f(i, j); //x,y
            glEnd();
            m++;
            
        }
    }
}

void clear_chocoC_containers(int n){
    int m=0;
    float x;
    for(float i = 0.15; i > -0.15; i-=0.05){//x
        for(float j = -0.35; j > -0.9 ; j-=0.05){//y
            if(m>=n){
                return;
            }
            glPointSize(5.0f);
            glBegin(GL_POINTS);
            glColor3f(0.0f, 0.0f, 0.0f); // black
            glVertex2f(i, j); //x,y
            glEnd();
            m++;
            
        }
    }
}

void add_to_chocoC_containers(int n){
    clear_chocoC_containers(choco_cont[2]);
    int k = 1;
    int m=0;
    float x;
    for(float i = 0.15; i > -0.15; i-=0.05){//x
        for(float j = -0.35; j > -0.9; j-=0.05){//y
            if(m>=n){
                choco_cont[2]=m;
                return;
            }
            glPointSize(5.0f);
            glBegin(GL_POINTS);
            if (k == 1){
                glColor3f(1.0f, 1.0f, 0.0f);  //yellow
            }
            else{
                glColor3f(1.0f, 0.0f, 0.0f); //red
            }
            glVertex2f(i, j); //x,y
            glEnd();
            m++;

        }
    }
}


//function for the cartons
void clear_chocoA_cartons(int n){
    int m=0;
    float x;
    for(float i = 0.55; i > 0.2; i-=0.05){//x
        for(float j = 0.85; j > 0.3 ; j-=0.05){//y
            if(m>=n){
                return;
            }
            glPointSize(5.0f);
            glBegin(GL_POINTS);
            glColor3f(0.0f, 0.0f, 0.0f); // black
            glVertex2f(i, j); //x,y
            glEnd();
            m++;
            
        }
    }
}

void add_to_chocoA_cartons(int n){
    clear_chocoA_cartons(choco_cartons[0]);
    int k = 1;
    int m=0;
    float x;
    for(float i = 0.55; i > 0.2; i-=0.05){//x
        for(float j = 0.85; j > 0.3 ; j-=0.05){//y
            if(m>=n){
                choco_cartons[0]=m;
                return;
            }
            glPointSize(5.0f);
            glBegin(GL_POINTS);
            if (k == 1){
                glColor3f(0.0f, 1.0f, 0.0f); //green
            }
            else{
                glColor3f(1.0f, 0.0f, 0.0f); //red
            }
            glVertex2f(i, j); //x,y
            glEnd();
            m++;
            
        }
    }
}

void clear_chocoB_cartons(int n){
    int m=0;
    float x;
    for(float i = 0.55; i > 0.2; i-=0.05){//x
        for(float j = 0.25; j > -0.25 ; j-=0.05){//y
            if(m>=n){
                return;
            }
            glPointSize(5.0f);
            glBegin(GL_POINTS);
            glColor3f(0.0f, 0.0f, 0.0f); // black
            glVertex2f(i, j); //x,y
            glEnd();
            m++;
            
        }
    }
}

void add_to_chocoB_cartons(int n){
    clear_chocoB_cartons(choco_cartons[1]);
    int k = 1;
    int m=0;
    float x;
    for(float i = 0.55; i > 0.2; i-=0.05){//x
        for(float j = 0.25; j > -0.25 ; j-=0.05){//y
            if(m>=n){
                choco_cartons[1]=m;
                return;
            }
            glPointSize(5.0f);
            glBegin(GL_POINTS);
            if (k == 1){
                glColor3f(0.0f, 0.0f, 1.0f); //blue
            }
            else{
                glColor3f(1.0f, 0.0f, 0.0f); //red
            }
            glVertex2f(i, j); //x,y
            glEnd();
            m++;
            
        }
    }
}

void clear_chocoC_cartons(int n){
    int m=0;
    float x;
    for(float i = 0.55; i > 0.2; i-=0.05){//x
        for(float j = -0.35; j > -0.9 ; j-=0.05){//y
            if(m>=n){
                return;
            }
            glPointSize(5.0f);
            glBegin(GL_POINTS);
            glColor3f(0.0f, 0.0f, 0.0f); // black
            glVertex2f(i, j); //x,y
            glEnd();
            m++;
            
        }
    }
}

void add_to_chocoC_cartons(int n){
    clear_chocoC_cartons(choco_cartons[2]);
    int k = 1;
    int m=0;
    float x;
    for(float i = 0.55; i > 0.2; i-=0.05){//x
        for(float j = -0.35; j > -0.9; j-=0.05){//y
            if(m>=n){
                choco_cartons[2]=m;
                return;
            }
            glPointSize(5.0f);
            glBegin(GL_POINTS);
            if (k == 1){
                glColor3f(1.0f, 1.0f, 0.0f);  //yellow
            }
            else{
                glColor3f(1.0f, 0.0f, 0.0f); //red
            }
            glVertex2f(i, j); //x,y
            glEnd();
            m++;
            
        }
    }
}


// function for chocolate after printing
void clear_printed(int n){
    int m=0;
    float x;
    for(float i = -0.25; i > -0.6; i-=0.05){//x
        for(float j = 0.85; j > -0.9 ; j-=0.05){//y
            if(m>=n){
                return;
            }
            glPointSize(5.0f);
            glBegin(GL_POINTS);
            glColor3f(0.0f, 0.0f, 0.0f); // black
            glVertex2f(i, j); //x,y
            glEnd();
            m++;
            
        }
    }
}

void add_to_printed(int n){
    clear_printed(p);
    int k = 1;
    int m=0;
    float x;
    for(float i = -0.25; i > -0.6; i-=0.05){//x
        for(float j = 0.85; j > -0.9 ; j-=0.05){//y
            if(m>=n){
                p=m;
                return;
            }
            glPointSize(5.0f);
            glBegin(GL_POINTS);
            if (k == 1){
                glColor3f(1.0f, 1.0f, 1.0f); //white
            }
            else{
                glColor3f(1.0f, 0.0f, 0.0f); //red
            }
            glVertex2f(i, j); //x,y
            glEnd();
            m++;
            
        }
    }
}


// function for the storage
void clear_storage(int n){
    int m=0;
    float x;
    for(float i = 0.95; i > 0.6; i-=0.05){//x
        for(float j = 0.85; j > -0.9 ; j-=0.05){//y
            if(m>=n){
                return;
            }
            glPointSize(5.0f);
            glBegin(GL_POINTS);
            glColor3f(0.0f, 0.0f, 0.0f); // black
            glVertex2f(i, j); //x,y
            glEnd();
            m++;
            
        }
    }
}

void add_to_storage(int n){
    clear_storage(s);
    int k = 1;
    int m=0;
    float x;
    for(float i = 0.95; i > 0.6; i-=0.05){//x
        for(float j = 0.85; j > -0.9 ; j-=0.05){//y
            if(m>=n){
                s=m;
                return;
            }
            glPointSize(5.0f);
            glBegin(GL_POINTS);
            if (k == 1){
                glColor3f(1.0f, 1.0f, 1.0f); //white
            }
            else{
                glColor3f(1.0f, 0.0f, 0.0f); //red
            }
            glVertex2f(i, j); //x,y
            glEnd();
            m++;
            
        }
    }
}


//function for the trucks
void clear_truck1(){
    glColor3f(0.0f, 0.0f, 0.0f); // black
    glBegin(GL_LINE_LOOP);
     glVertex2f(1.1f, 0.85f); //x, y
     glVertex2f(1.1f, 0.55f); 
     glVertex2f(1.3f, 0.55f); 
     glVertex2f(1.3f, 0.85f); 
    glEnd();

    glBegin(GL_LINE_LOOP);
     glVertex2f(1.15f, 0.55f); //x, y
     glVertex2f(1.15f, 0.45f); 
     glVertex2f(1.25f, 0.45f);
     glVertex2f(1.25f, 0.55f); 
    glEnd();
}

void add_to_truck1(){
   if(var[4]==1){
        glColor3f(1.0f, 0.0f, 1.0f);
    }
    else{
        glColor3f(1.0, 1.0, 1.0);//white
    }
    
    glBegin(GL_LINE_LOOP);
     glVertex2f(1.1f, 0.85f); //x, y
     glVertex2f(1.1f, 0.55f); 
     glVertex2f(1.3f, 0.55f); 
     glVertex2f(1.3f, 0.85f); 
    glEnd();

    glBegin(GL_LINE_LOOP);
     glVertex2f(1.15f, 0.55f); //x, y
     glVertex2f(1.15f, 0.45f); 
     glVertex2f(1.25f, 0.45f);
     glVertex2f(1.25f, 0.55f); 
    glEnd();
}

void clear_truck2(){
    glColor3f(0.0f, 0.0f, 0.0f); // black
    //truck 2
    glBegin(GL_LINE_LOOP);
     glVertex2f(1.1f, 0.25f); //x, y
     glVertex2f(1.1f, -0.05f); 
     glVertex2f(1.3f, -0.05f); 
     glVertex2f(1.3f, 0.25f); 
    glEnd();

    glBegin(GL_LINE_LOOP);
     glVertex2f(1.15f, -0.05f); //x, y
     glVertex2f(1.15f, -0.15f); 
     glVertex2f(1.25f, -0.15f);
     glVertex2f(1.25f, -0.05f); 
    glEnd();
}

void add_to_truck2(){
    if(var[4]==2){
        glColor3f(1.0f, 0.0f, 1.0f);
    }
    else{
        glColor3f(1.0, 1.0, 1.0);//white
    }

    //truck 2
    glBegin(GL_LINE_LOOP);
     glVertex2f(1.1f, 0.25f); //x, y
     glVertex2f(1.1f, -0.05f); 
     glVertex2f(1.3f, -0.05f); 
     glVertex2f(1.3f, 0.25f); 
    glEnd();

    glBegin(GL_LINE_LOOP);
     glVertex2f(1.15f, -0.05f); //x, y
     glVertex2f(1.15f, -0.15f); 
     glVertex2f(1.25f, -0.15f);
     glVertex2f(1.25f, -0.05f); 
    glEnd();
}

void clear_truck3(){
    glColor3f(0.0f, 0.0f, 0.0f); // black
    glBegin(GL_LINE_LOOP);
     glVertex2f(1.1f, -0.35f); //x, y
     glVertex2f(1.1f, -0.65f); 
     glVertex2f(1.3f, -0.65f); 
     glVertex2f(1.3f, -0.35f); 
    glEnd();

    glBegin(GL_LINE_LOOP);
     glVertex2f(1.15f, -0.65f); //x, y
     glVertex2f(1.15f, -0.75f); 
     glVertex2f(1.25f, -0.75f);
     glVertex2f(1.25f, -0.65f); 
    glEnd();
}

void add_to_truck3(){
    if(var[4]==3){
        glColor3f(1.0f, 0.0f, 1.0f);
    }
    else{
        glColor3f(1.0, 1.0, 1.0);//white
    }

    //truck 3
    glBegin(GL_LINE_LOOP);
     glVertex2f(1.1f, -0.35f); //x, y
     glVertex2f(1.1f, -0.65f); 
     glVertex2f(1.3f, -0.65f); 
     glVertex2f(1.3f, -0.35f); 
    glEnd();

    glBegin(GL_LINE_LOOP);
     glVertex2f(1.15f, -0.65f); //x, y
     glVertex2f(1.15f, -0.75f); 
     glVertex2f(1.25f, -0.75f);
     glVertex2f(1.25f, -0.65f); 
    glEnd();
}



void progress_barA(float p){
    // Set the color of the second progress bar to black
    glColor3f(0.0f, 1.0f, 0.0f); //green


            // Draw the third rectangle
    glBegin(GL_QUADS);
        glVertex2f(-1.0,0.975);
        glVertex2f(-1.0+p, 0.975);
        glVertex2f(-1.0+p, 0.925);
        glVertex2f(-1.0, 0.925);
    glEnd();
}

void progress_barB(float p){
    // Set the color of the second progress bar to purple
    glColor3f(0.0f, 0.0f, 1.0f); //blue

    // Draw the second progress bar
    glBegin(GL_QUADS);
        glVertex2f(-0.2,0.975);
        glVertex2f(-0.2+p, 0.975);
        glVertex2f(-0.2+p, 0.925);
        glVertex2f(-0.2, 0.925);
    glEnd();
}

void progress_barC(float p){
    // Set the color of the second progress bar to yellow
    glColor3f(1.0f, 1.0f, 0.0f);  //yellow


    // Draw the second progress bar
    glBegin(GL_QUADS);
        glVertex2f(0.6,0.975);
        glVertex2f(0.6+p, 0.975);
        glVertex2f(0.6+p, 0.925);
        glVertex2f(0.6, 0.925);
    glEnd();
}

void drawPageFrame() {  

    glColor3f(1.0, 1.0, 1.0);//white

    //outer frame
    glBegin(GL_LINE_LOOP);
     glVertex2f(1.4f, 0.9f); //x, y
     glVertex2f(-1.4f, 0.9f); 
     glVertex2f(-1.4f, -0.9f); 
     glVertex2f(1.4f, -0.9f); 
    glEnd();

    //lines area
    glBegin(GL_LINES);
     glVertex2f(-1.0f, 0.9f); 
     glVertex2f(-1.0f, -0.9f); 
    glEnd();

    //choco area
    glBegin(GL_LINES);
     glVertex2f(-0.6f, 0.9f); 
     glVertex2f(-0.6f, -0.9f); 
    glEnd();

    glBegin(GL_LINES);
     glVertex2f(-1.0f, 0.3f); 
     glVertex2f(-0.6f, 0.3f); 
    glEnd();

    glBegin(GL_LINES);
     glVertex2f(-1.0f, -0.3f); 
     glVertex2f(-0.6f, -0.3f); 
    glEnd();

    //print area
    glBegin(GL_LINES);
     glVertex2f(-0.2f, 0.9f); 
     glVertex2f(-0.2f, -0.9f); 
    glEnd();

    //containers area
    glBegin(GL_LINES);
     glVertex2f( 0.2f, 0.9f); 
     glVertex2f( 0.2f, -0.9f); 
    glEnd();

    glBegin(GL_LINES);
     glVertex2f(-0.2f, 0.3f); 
     glVertex2f(0.2f, 0.3f); 
    glEnd();

    glBegin(GL_LINES);
     glVertex2f(-0.2f, -0.3f); 
     glVertex2f(0.2f, -0.3f); 
    glEnd();

    //cartons area
    glBegin(GL_LINES);
     glVertex2f( 0.6f, 0.9f); 
     glVertex2f( 0.6f, -0.9f); 
    glEnd();

    glBegin(GL_LINES);
     glVertex2f(0.2f, 0.3f); 
     glVertex2f(0.6f, 0.3f); 
    glEnd();

    glBegin(GL_LINES);
     glVertex2f(0.2f, -0.3f); 
     glVertex2f(0.6f, -0.3f); 
    glEnd();

    //storage area
    glBegin(GL_LINES);
     glVertex2f( 1.0f, 0.9f); 
     glVertex2f( 1.0f, -0.9f); 
    glEnd();

    //trucks
    glBegin(GL_LINES);
     glVertex2f(1.0f, 0.3f); 
     glVertex2f(1.4f, 0.3f); 
    glEnd();

    glBegin(GL_LINES);
     glVertex2f(1.0f, -0.3f); 
     glVertex2f(1.4f, -0.3f); 
    glEnd();

    //progress bar showing progress for A
    glBegin(GL_LINE_LOOP);
        glVertex2f(-1.0, 0.975);
        glVertex2f(-0.6, 0.975);
        glVertex2f(-0.6, 0.925);
        glVertex2f(-1.0, 0.925);
    glEnd();

    //progress bar showing progress for B
    glBegin(GL_LINE_LOOP);
        glVertex2f(-0.2, 0.975);
        glVertex2f(0.2, 0.975);
        glVertex2f(0.2, 0.925);
        glVertex2f(-0.2, 0.925);
    glEnd();

    //progress bar showing progress for C
    glBegin(GL_LINE_LOOP);
        glVertex2f(0.6, 0.975);
        glVertex2f(1.0, 0.975);
        glVertex2f(1.0, 0.925);
        glVertex2f(0.6, 0.925);
    glEnd();

    srand(time(NULL));

    if (var[0]>76){
        var[0]=76;
    }
    add_to_chocoA(var[0]%77);

    if (var[1]>76){
        var[1]=76;
    }
    add_to_chocoB(var[1]%77);

    if (var[2]>76){
        var[2]=76;
    }
    add_to_chocoC(var[2]%77);

    int x = var[3];
    if (x>245){
        x=245;
    }
    add_to_printed(x%245);

    if (var[6]>76){
        var[6]=76;
    }
    add_to_chocoA_containers(var[6]%77);

    if (var[7]>76){
        var[7]=76;
    }
    add_to_chocoB_containers(var[7]%77);

    if (var[8]>76){
        var[8]=76;
    }
    add_to_chocoC_containers(var[8]%77);

    if (var[9]>76){
        var[9]=76;
    }
    add_to_chocoA_cartons(var[9]%77);

    if (var[10]>76){
        var[10]=76;
    }   
    add_to_chocoB_cartons(var[10]%77);

    if (var[11]>76){
        var[11]=76;
    }
    add_to_chocoC_cartons(var[11]%77);

 
    int y = var[12]+var[13]+var[14];
    if (y>245){
        y=245;
    }
    add_to_storage(y%245);

    //int k1 = rand()%2;
    if ( var[15] == 0 ){
        add_to_truck1();
    }
    else{
        clear_truck1();
    }

    //int k2 = rand()%2;
    if ( var[16] == 0 ){
        add_to_truck2();
    }
    else{
        clear_truck2();
    }

    //int k3 = rand()%2;
    if ( var[17] == 0 ){
        add_to_truck3();
    }
    else{
        clear_truck3();
    }

    
    float p_A = ((float)var[18]/a[2])*0.4;
    if (p_A > 0.4){
        p_A = 0.4;
    }
    progress_barA(p_A);

    float p_B = ((float)var[19]/a[3])*0.4;
    if (p_B > 0.4){
        p_B = 0.4;
    }
    progress_barB(p_B);

    float p_C = ((float)var[20]/a[4])*0.4;
    if (p_C > 0.4){
        p_C = 0.4;
    }
    progress_barC(p_C);


    glFlush();


}



//**********************add dots to the most right*********************




//************************* remove dots********************************

/* Handler for window re-size event. Called back when the window first appears and
   whenever the window is re-sized with its new width and height */
void reshape(GLsizei width, GLsizei height) {  // GLsizei for non-negative integer
   // Compute aspect ratio of the new window
   if (height == 0) height = 1;                // To prevent divide by 0
   GLfloat aspect = (GLfloat)width / (GLfloat)height;
 
   // Set the viewport to cover the new window
   glViewport(0, 0, width, height);
 
   // Set the aspect ratio of the clipping area to match the viewport
   glMatrixMode(GL_PROJECTION);  // To operate on the Projection matrix
   glLoadIdentity();
   if (width >= height) {
     // aspect >= 1, set the height from -1 to 1, with larger width
      gluOrtho2D(-1.0 * aspect, 1.0 * aspect, -1.0, 1.0);
   } else {
      // aspect < 1, set the width to -1 to 1, with larger height
     gluOrtho2D(-1.0, 1.0, -1.0 / aspect, 1.0 / aspect);
   }
}

//end the remove dots **************************************************
void display() {

    glClear(GL_COLOR_BUFFER_BIT);

    // Draw the page frame
    drawPageFrame();

 

    // Swap the buffers to update the display
    glutSwapBuffers();
    //sleep(2);
    glutPostRedisplay();
    // Clear the window

}
//*************************************remove function********************


//***********************end of remove function*********************
int main(int argc, char** argv) {

    read_param();

    ipc_key = ftok(".", 'C');
    if ( (shmid_open = shmget(ipc_key, 0, 0)) < 0 ) {
        perror("shmget fail");
        exit(1);
    }

    if ( (var = (int *) shmat(shmid_open, 0, 0)) == (int *) -1 ) {
        perror("shmat: fail");
        exit(2);
    }



    // ipc_key = ftok(".", 'S');
    // //printf("officer ipc_key:%d\n", ipc_key);
    // int semid_size = semget(ipc_key, 1, 0);  // Attach to the semaphore set  
    // if (semid_size == -1)
    // {
    //     if (errno != 0)
    //     {
    //         perror("semget");
    //         exit(1);
    //     }
        
    //}
    //printf("officer semid_size=%d\n",semid_size);
    // Initialize GLUT
    glutInit(&argc, argv);

    // Set the window size and position
   
    glutInitWindowSize(1080, 720);
    glutInitWindowPosition(100, 100);
  

    // Set the display mode to double buffering
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

    // Create the window
    glutCreateWindow("OIM");
    // Set the display callback function
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);

    // Enter the GLUT event loop
    glutMainLoop();



    return 0;
}