#ifndef __LOCAL_H_
#define __LOCAL_H_

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <time.h>
#include <wait.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <pthread.h>  


pthread_t collecters[2],thread_line8,thread_containers[3],thread_cartons[3],thread_storage[2],thread_truck_emp[2],thread_trucks[3],thread_open;
pthread_t thread_line1[3][8],thread_line2[2][6],thread_line3[2][5];
pthread_mutex_t mutex_typeA[3][8],mutex_typeB[2][6],mutex_typeC[2][5];
pthread_mutex_t Amemory_mutex[3];
pthread_mutex_t Cmemory_mutex[2];
pthread_mutex_t collect_choco_mutex=PTHREAD_MUTEX_INITIALIZER; 
pthread_mutex_t expiry_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t containers_mutex=PTHREAD_MUTEX_INITIALIZER; 
pthread_mutex_t fill_cartons_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t store_cartons_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t fill_truck_mutex=PTHREAD_MUTEX_INITIALIZER;

int a[13];
time_t initial, current,t;
key_t ipc_key;
int shmid_open,shmid_extra;

int cID = 0;
int cIDc = 0;

// a structure that will hold the chocolate piece a and keep count of it steps
typedef struct {
    int steps[8];  
    int finishedSteps;
    int id;
} chocoA;

// a structure that will hold the chocolate piece B and keep count of it steps
typedef struct {
    int steps[5];  
    int finishedSteps;
    int id;
} chocoC;

// general structure for the employee
struct emp_info
{
	int line_id;
	int emp_id;
};


//creating allias for the NodeA linked list
typedef struct NodeA NodeA;
//creating a linked list for chocolate of type A
struct NodeA {
    chocoA *chocolate;
    NodeA *next;
};

//creating allias for the NodaB linked list
typedef struct NodeC NodeC;
//creating a linked list for chocolate of type C
struct NodeC {
    chocoC *chocolate;
    NodeC *next;
};

//using allias define a linkedlist for each line for A chocolate, this will act as the memory to enable the out of order
NodeA *linesA[3];

//using allias define a linkedlist for each line for C chocolate, this will act as the memory to enable the out of order
NodeC *linesC[2];



// function that will copy the informations of the structure of the chocolate A 
chocoA *copyChoco(chocoA *chocolate) {
    chocoA *choco = (chocoA *)malloc(sizeof(chocoA));

    if (choco == NULL) {
        perror("error in copychocoA");
    }

    choco->id = chocolate->id;
    choco->finishedSteps = chocolate->finishedSteps;
    for (int i = 0; i < 8; i++) {
        choco->steps[i] = chocolate->steps[i];
    }
    return choco;
}

// function that will copy the informations of the structure of the chocolate C
chocoC *copyChocoC(chocoC *chocolate) {
    chocoC *choco = (chocoC *)malloc(sizeof(chocoC));

    if (choco == NULL) {
        perror("error in copychocoC");
    }

    choco->id = chocolate->id;
    choco->finishedSteps = chocolate->finishedSteps;
    for (int i = 0; i < 5; i++) {
        choco->steps[i] = chocolate->steps[i];
    }
    return choco;
}


// add chocolate a to the memory
void addToMemA(chocoA *choco, int line) {
    NodeA *head = linesA[line]; //take the first element in the memory of line as head
    if (head == NULL) { //memory is empty, add the new chocolate to it
        head = (NodeA *)malloc(sizeof(NodeA));

        if (head == NULL) { //error id definition
            perror("error in addtoMemA head == NULL");
        }

        head->chocolate = copyChoco(choco); //copy the informations in chocolate
        head->next = NULL; //one element still, so next in null
        linesA[line] = head; 
        return;
    }

    // if there is a chocolate in the memory (memory not empty)
    NodeA *new; //define new struct
    new = (NodeA *)malloc(sizeof(NodeA)); 

    if (new == NULL) {
        perror("error in addtoMemA new == NULL");
    }

    new->chocolate = copyChoco(choco); //copy chocolate to new
    new->next = head; //make the next element for it as head
    linesA[line] = new; //make new the first element/head
}

//get a chocolate from memeory for A lines
chocoA *getFromMemA(int id, int line) { //id is emp id/step, line is line
    NodeA *head = linesA[line]; //take the head of the memory

    if (head == NULL) {  // empty memory
        return NULL;
    } else if (head->next == NULL) {  // memory with one chocolate
        if (head->chocolate->steps[id] == 0) { //if the steps for this employee == 0, not accomplished yet
            chocoA *choco = copyChoco(head->chocolate);
            free(head->chocolate);
            free(head);
            linesA[line] = NULL;
            return choco;
        }
        else{
            return NULL;
        }
    }

    //else there is more chocolates in the memory
    NodeA *prev = head;
    NodeA *temp = prev->next;
    // iterate in the memory till u find the element
    while (temp != NULL) { //for the first time if null, one element, covered above
        if (temp->chocolate->steps[id] == 0) { //found not accomplished
            prev->next = temp->next; //adjust the list and free old one
            temp->next = NULL;
            chocoA *choco = copyChoco(temp->chocolate);
            free(temp->chocolate);
            free(temp);
            return choco;
        }
        prev = prev->next;
        temp = temp->next;
    }
    return NULL;
}


// add chocolate c to the memory 
void addToMemC(chocoC *choco, int line) {
    NodeC *head = linesC[line]; //take the first element in the memory of line as head
    if (head == NULL) { //memory is empty, add the new chocolate to it
        head = (NodeC *)malloc(sizeof(NodeC));

        if (head == NULL) {
            perror("error in addtoMemC head == NULL");
        }

        head->chocolate = copyChocoC(choco); //copy the informations in chocolate
        head->next = NULL; //one element still, so next in null
        linesC[line] = head;
        return;
    }

    // if there is a chocolate in the memory (memory not empty)
    NodeC *new; //define new struct
    new = (NodeC *)malloc(sizeof(NodeC));

    if (new == NULL) {
        perror("error in addtoMemC new == NULL");
    }

    new->chocolate = copyChocoC(choco); //copy chocolate to new
    new->next = head; //make the next element for it as head
    linesC[line] = new; //make new the first element/head
}

chocoC *getFromMemC(int id, int line) {
    NodeC *head = linesC[line];

    if (head == NULL) {  // empty memory
        return NULL;
    } else if (head->next == NULL) {  // memory with one chocolate
        if (head->chocolate->steps[id] == 0) { //if the steps for this employee == 0, not accomplished yet
            chocoC *choco = copyChocoC(head->chocolate);
            free(head->chocolate);
            free(head);
            linesC[line] = NULL;
            return choco;
        }
    }

    //else there is more chocolates in the memory
    NodeC *prev = head;
    NodeC *temp = prev->next;
    // iterate in the memory till u find the element
    while (temp != NULL) {//for the first time if null, one element, covered above
        if (temp->chocolate->steps[id] == 0) {//found not accomplished
            prev->next = temp->next;//adjust the list and free old one
            temp->next = NULL;
            chocoC *choco = copyChocoC(temp->chocolate);
            free(temp->chocolate);
            free(temp);
            return choco;
        }
        prev = prev->next;
        temp = temp->next;
    }
    return NULL;
}


// get time
time_t current_time(){
    return time(NULL);
}

//read param
void read_param(){
    FILE* ptr;
	char ch[30];
    int y= 0;

	// Opening file in reading mode
	ptr = fopen("param.txt", "r");

    if (NULL == ptr) {
		printf("file can't be opened \n");
	}

    for ( int i = 0; i < 13; i++){

        fgets(ch,255,ptr);
        //printf("%s", ch);

        char * token = strtok(ch, "=");
        while (token != NULL) {
            //printf("%s\n",token);
            if(y==1){
                sprintf(ch,"%s",token);
                
            }
            token = strtok(NULL, "=");
            y++;
        }

        int x = atoi(ch);
        //printf("%d\n",x);
        a[i] = x;
        y=0;

    }

	// Closing the file
	fclose(ptr);
}


#endif