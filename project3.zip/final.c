#include "local.h"

void line1(int *); 
void line2(int *); 
void line3(int *); 
void collect_choco(int *);
void out_of_order(int *);
void fill_containers(int *);
void fill_cartons(int *);
void expiry(int *);
void store_cartons(int *);
void fill_trucks(int *);
void truck(int *);
void open_thread(int *);
void create_shm();
int A_prod=0, A_patch=0, A_patch_p=0,A_containers=0,A_C=0,A_cartons=0,A_storage=0,A_truck=0,A_final=0;
int B_prod=0, B_patch=0, B_patch_p=0,B_containers=0,B_C=0,B_cartons=0,B_storage=0,B_truck=0,B_final=0;
int C_prod=0, C_patch=0, C_patch_p=0,C_containers=0,C_C=0,C_cartons=0,C_storage=0,C_truck=0,C_final=0;
int storage_flag=0,suspend=0;
int t1_f=0,t2_f=0,t3_f=0;
int s1=1,s2=0,s3=0;
int A_steps[3][8],B_steps[2][6],C_steps[2][5];
int *var;
int openGl;

int main(int argc, char **argv) {
    srand((unsigned) time(&t) + getpid());
    read_param();
    int b[7];
    create_shm();

    initial = current_time();

    for (int i = 0; i < 13; i++){
        printf("a[%d]=%d\n",i,a[i]);
    }
    for(int i = 0; i<7; i++){
        b[i]=i+1;
    }

    // thread for opengl var
    if (pthread_create(&thread_open, NULL, (void *)open_thread, (void*) NULL))
                perror("Error: Thread Cannot Be Created");

    openGl = fork();
    if( openGl == 0){
        execlp("./openGL", "openGL",(char *) NULL);
    }

    // mutex for A memory for out of order choch A
    for (int i = 0; i < 3; i++) {
        pthread_mutex_init(&Amemory_mutex[i], NULL);
    }

    // mutex for C memory for out of order choch C
    for (int i = 0; i < 2; i++) {
        pthread_mutex_init(&Cmemory_mutex[i], NULL);
    }

    // mutex and employees for 3 line choco A
   for (int i = 0; i < 3; i++){
        for (int j = 0; j < 8; j++){
            struct emp_info *info;
            info = malloc(sizeof(struct emp_info));
            (*info).line_id = i;
            (*info).emp_id = j;
            A_steps[i][j] = 0;
            pthread_mutex_init(&mutex_typeA[i][j], NULL);
            if (pthread_create(&thread_line1[i][j], NULL, (void *) line1, (void*) info))
                perror("Error: Thread Cannot Be Created");
        }
    }

    // mutex and employees for 2 line choco B
    for (int i = 0; i < 2; i++){
        for (int j = 0; j < 6; j++){
            struct emp_info *info;
            info = malloc(sizeof(struct emp_info));
            (*info).line_id = i;
            (*info).emp_id = j;
            B_steps[i][j]=0;
            pthread_mutex_init(&mutex_typeB[i][j], NULL);
            if (pthread_create(&thread_line2[i][j], NULL, (void *) line2, (void*) info))
                perror("Error: Thread Cannot Be Created");
        }
    }

   // mutex and employees for 2 line choco C 
    for (int i = 0; i < 2; i++){
        for (int j = 0; j < 5; j++){
            struct emp_info *info;
            info = malloc(sizeof(struct emp_info));
            (*info).line_id = i;
            (*info).emp_id = j;
            C_steps[i][j]=0;
            pthread_mutex_init(&mutex_typeC[i][j], NULL);
            if (pthread_create(&thread_line3[i][j], NULL, (void *) line3, (void*) info))
                perror("Error: Thread Cannot Be Created");
        }
    }


    //2 collecters employees threads for patch collecting step 5
    for (int i = 0; i < 2; i++){
        if (pthread_create(&collecters[i], NULL, (void *)collect_choco, (void*) NULL))
            perror("Error: Thread Cannot Be Created"); 
    }

    //line 8 for expiry printing step 5
    if (pthread_create(&thread_line8, NULL, (void *)expiry, (void*) NULL))
                perror("Error: Thread Cannot Be Created");


    //3 employees to fill the containers, step 6
    for (int i = 0; i < 3; i++){
        if (pthread_create(&thread_containers[i], NULL, (void *)fill_containers, (void*) NULL))
            perror("Error: Thread Cannot Be Created"); 
    }

    int iii[3];
    iii[0]=0;
    iii[1]=1;
    iii[2]=2;
    //3 collecters employees who collects in cartons 6
    for (int i = 0; i < 3; i++){
        if (pthread_create(&thread_cartons[i], NULL, (void *)fill_cartons, (void*) &iii[i]))
            perror("Error: Thread Cannot Be Created"); 
    }



    //2 storage employees who store the cartons 7
    for (int i = 0; i < 2; i++){
        if (pthread_create(&thread_storage[i], NULL, (void *)store_cartons, (void*) NULL))
            perror("Error: Thread Cannot Be Created"); 
    }

    // t=2 truck employees
    for (int i = 0; i < 2; i++){
        if (pthread_create(&thread_truck_emp[i], NULL, (void *)fill_trucks, (void*) NULL))
            perror("Error: Thread Cannot Be Created"); 
    }

    // t=3 trucks
    int iiii[3];
    iiii[0]=0;
    iiii[1]=1;
    iiii[2]=2;
    for (int i = 0; i < 3; i++){
        if (pthread_create(&thread_trucks[i], NULL, (void *)truck, (void*) &iiii[i]))
            perror("Error: Thread Cannot Be Created"); 
    }
    
    
    while(1){
        if( (int) initial + a[5]*60 < (int) current_time()){
            printf("intial %d, current %d\n",(int) initial + a[5]*60,(int) current_time());
            break;
        }
        else if ( A_final >= a[2] && B_final >= a[3] && C_final >= a[4]){
            printf("The factory has produced typeA, typeB and typeC carton boxes that exceed a user-defined threshold for each type\n");
            break;
        }
    }

    printf("A:%d, B=%d, C=%d, A patch = %d, B patch = %d, C patch = %d, A patch p = %d, B patch p = %d, C patch p = %d\n",A_prod,B_prod,C_prod,A_patch,B_patch,C_patch,A_patch_p,B_patch_p,C_patch_p);
    printf("A_Container=%d, B_Container=%d, C_Container=%d\n",A_containers,B_containers,C_containers);
    printf("A_C=%d, B_C=%d, C_C=%d, A_cartons =%d, B_cartons=%d, C_cartons=%d\n",A_C,B_C,C_C,A_cartons,B_cartons,C_cartons);
    printf("A_storage = %d, B_storage = %d, C_storage = %d\n",A_storage,B_storage,C_storage);
    printf("A_truck %d, B_truck %d, C_truck %d, A_final = %d, B_final = %d, C_final = %d\n",A_truck,B_truck,C_truck,A_final,B_final,C_final);

    pthread_mutex_destroy(&collect_choco_mutex);
    pthread_mutex_destroy(&expiry_mutex);
    pthread_mutex_destroy(&containers_mutex);
    pthread_mutex_destroy(&fill_cartons_mutex);
    pthread_mutex_destroy(&store_cartons_mutex);

    for (int i = 0; i < 3; i++) {
        pthread_mutex_destroy(&Amemory_mutex[i]);
    }

    for (int i = 0; i < 2; i++) {
        pthread_mutex_destroy(&Cmemory_mutex[i]);
    }


    //DELETE LIN3 3 FOR CHOCO A
    for (int i = 0; i < 3; i++){
        for (int j = 0; j < 8; j++){
            pthread_mutex_destroy(&mutex_typeA[i][j]);
            pthread_cancel(thread_line1[i][j]);
        }
    }

    //DELETE LIN3 2 FOR CHOCO B
    for (int i = 0; i < 2; i++){
        for (int j = 0; j < 6; j++){
            pthread_mutex_destroy(&mutex_typeB[i][j]);
            pthread_cancel(thread_line2[i][j]);
        }
    }

    //DELETE LIN3 2 FOR CHOCO C
    for (int i = 0; i < 2; i++){
        for (int j = 0; j < 5; j++){
            pthread_mutex_destroy(&mutex_typeC[i][j]);
            pthread_cancel(thread_line3[i][j]);
        }
    }

    //delete 2 collecters employees
    for (int i = 0; i < 2; i++){
        pthread_cancel(collecters[i]);
    }

    //delete line 8
    pthread_cancel(thread_line8);

    //delete 3 employees to fill the containers, step 6
    for (int i = 0; i < 3; i++){
        pthread_cancel(thread_containers[i]); 
    }

    //delete 3 collecters employees
    for (int i = 0; i < 3; i++){
        pthread_cancel(thread_cartons[i]);
    }

    //2 storage employees who store the cartons 7
    for (int i = 0; i < 2; i++){
        pthread_cancel(thread_storage[i]);
    }

    // t=2 truck employees
    for (int i = 0; i < 2; i++){
        pthread_cancel(thread_truck_emp[i]);
    }

    for (int i = 0; i < 3; i++){
        pthread_cancel(thread_trucks[i]);
    }

    pthread_cancel(thread_open);

    shmdt(open);
    shmctl(shmid_open, IPC_RMID, (struct shmid_ds *) 0);


}

void line1(int *data)  
{

    // Receive Data Encapsulated Inside a Struct, Extract Data and Free the Struct
    struct emp_info *my_info = (struct emp_info*)data;
    int line = my_info->line_id, id = my_info->emp_id;
    free (data);
    // printf("line %d, emp %d\n",line,id);
    // fflush(stdout);

    int prev_id = id - 1;

    while(1){
        if(suspend==0){
            sleep(1);
            if (id == 0) { //initial step, no previous
                pthread_mutex_lock(&mutex_typeA[line][id]);
                int dur = (int) (a[0] + (rand() % (a[1] - a[0])));   
                //printf("thread A of line %d, emp %d sleep %d\n",line,id,dur);
                //fflush(stdout);
                sleep(dur);
                A_steps[line][id]++;
                pthread_mutex_unlock(&mutex_typeA[line][id]);
            }
            else if (id < 3 && id > 0) { //in order steps, adjusts the A_steps
                pthread_mutex_lock(&mutex_typeA[line][prev_id]);
                if (A_steps[line][prev_id] != 0){
                    pthread_mutex_lock(&mutex_typeA[line][id]);
                    int dur = (int) (a[0] + (rand() % (a[1] - a[0])));   
                    //printf("thread A of line %d, emp %d sleep %d\n",line,id,dur);
                    //fflush(stdout);
                    sleep(dur);
                    A_steps[line][id]++;
                    A_steps[line][prev_id]--;
                    pthread_mutex_unlock(&mutex_typeA[line][id]);
                }
                pthread_mutex_unlock(&mutex_typeA[line][prev_id]);
            }
            else if (id == 3){ //final in order step, add the info of chocolate to the memory
                pthread_mutex_lock(&mutex_typeA[line][prev_id]);
                if (A_steps[line][prev_id] != 0){
                    pthread_mutex_lock(&Amemory_mutex[line]);
                    int dur = (int) (a[0] + (rand() % (a[1] - a[0])));   
                    chocoA *choco = malloc(sizeof(chocoA));
                    choco->id = ++cID;
                    choco->finishedSteps = 4;
                    for (int i = 0; i < 8; i++){
                        if (i < 4){
                            choco->steps[i] = 1; //finished
                        }
                        else{
                            choco->steps[i] = 0; //not finished
                        }
                    } 
                    addToMemA(choco, line);
                    A_steps[line][prev_id]--;
                    //printf("thread A of line %d, emp %d sleep %d\n",line,id,dur);
                    //fflush(stdout);
                    sleep(dur);
                    pthread_mutex_unlock(&Amemory_mutex[line]);
                }
                pthread_mutex_unlock(&mutex_typeA[line][prev_id]);
            }
            else{
                pthread_mutex_lock(&Amemory_mutex[line]);
                chocoA *choco = getFromMemA(id, line);
                pthread_mutex_unlock(&Amemory_mutex[line]);
                if (choco!=NULL){
                    choco->steps[id] = 1; //finish
                    choco->finishedSteps++; 
                    int dur = (int) (a[0] + (rand() % (a[1] - a[0])));
                    //printf("thread A of line %d, emp %d sleep %d, steps %d\n",line,id,dur,choco->finishedSteps);
                    //fflush(stdout);
                    sleep(dur);
                    if (choco->finishedSteps == 8) { //check end
                        A_prod++;
                        printf("choch A produced from line %d\n",line);
                        fflush(stdout);
                    }
                    else {
                        pthread_mutex_lock(&Amemory_mutex[line]);
                        addToMemA(choco, line);
                        pthread_mutex_unlock(&Amemory_mutex[line]);
                    } 
                }
                
            }
        }
    } 
   
}

void line2(int *data)  
{

        // Receive Data Encapsulated Inside a Struct, Extract Data and Free the Struct
    struct emp_info *my_info = (struct emp_info*)data;
    int line = my_info->line_id, id = my_info->emp_id;
    free (data);
    // printf("line %d, emp %d\n",line,id);
    // fflush(stdout);

    int prev_id = id - 1;
    
    while(1){ 
        if (suspend==0){
            sleep(1);
            if (id == 0) {
                pthread_mutex_lock(&mutex_typeB[line][id]);
                int dur = (int) (a[0] + (rand() % (a[1] - a[0])));   
                //printf("thread of B line %d, emp %d sleep %d\n",line,id,dur);
                //fflush(stdout);
                sleep(dur);
                B_steps[line][id]++;
                pthread_mutex_unlock(&mutex_typeB[line][id]);
            }
            else if (id < 5 && id > 0) {
                fflush(stdout);
                pthread_mutex_lock(&mutex_typeB[line][prev_id]);
                if (B_steps[line][prev_id] != 0){
                    pthread_mutex_lock(&mutex_typeB[line][id]);
                    int dur = (int) (a[0] + (rand() % (a[1] - a[0])));   
                    //printf("thread B of line %d, emp %d sleep %d\n",line,id,dur);
                    //fflush(stdout);
                    sleep(dur);
                    B_steps[line][id]++;
                    B_steps[line][prev_id]--;
                    pthread_mutex_unlock(&mutex_typeB[line][id]);
                }
                pthread_mutex_unlock(&mutex_typeB[line][prev_id]);
            }
            else{
                pthread_mutex_lock(&mutex_typeB[line][prev_id]);
                if (B_steps[line][prev_id] != 0){
                    pthread_mutex_lock(&mutex_typeB[line][id]);
                    int dur = (int) (a[0] + (rand() % (a[1] - a[0])));   
                    //printf("thread B of line %d, emp %d sleep %d\n",line,id,dur);
                    //fflush(stdout);
                    sleep(dur);
                    B_prod++;
                    B_steps[line][prev_id]--;
                    printf("choch b produced from line %d\n",line);
                    pthread_mutex_unlock(&mutex_typeB[line][id]);
                }
                pthread_mutex_unlock(&mutex_typeB[line][prev_id]);
                
            }
        }
    }
}

void line3(int *data)  
{
    // Receive Data Encapsulated Inside a Struct, Extract Data and Free the Struct
    struct emp_info *my_info = (struct emp_info*)data;
    int line = my_info->line_id, id = my_info->emp_id;
    free (data);
    // printf("line %d, emp %d\n",line,id);
    // fflush(stdout);

    int prev_id = id - 1;

    while(1){
        if(suspend==0){
            sleep(1);
            if (id == 0) {
                pthread_mutex_lock(&mutex_typeC[line][id]);
                int dur = (int) (a[0] + (rand() % (a[1] - a[0])));   
                // printf("thread C of line %d, emp %d sleep %d\n",line,id,dur);
                // fflush(stdout);
                sleep(dur);
                C_steps[line][id]++;
                pthread_mutex_unlock(&mutex_typeC[line][id]);
            }
            else if (id < 2 && id > 0) {
                pthread_mutex_lock(&mutex_typeC[line][prev_id]);
                if (C_steps[line][prev_id] != 0){
                    pthread_mutex_lock(&mutex_typeC[line][id]);
                    int dur = (int) (a[0] + (rand() % (a[1] - a[0])));   
                    // printf("thread C of line %d, emp %d sleep %d\n",line,id,dur);
                    // fflush(stdout);
                    sleep(dur);
                    C_steps[line][id]++;
                    C_steps[line][prev_id]--;
                    pthread_mutex_unlock(&mutex_typeC[line][id]);
                }
                pthread_mutex_unlock(&mutex_typeC[line][prev_id]);
            }
            else if (id == 2){
                pthread_mutex_lock(&mutex_typeC[line][prev_id]);
                if (C_steps[line][prev_id] != 0){
                    pthread_mutex_lock(&Cmemory_mutex[line]);
                    int dur = (int) (a[0] + (rand() % (a[1] - a[0])));   
                    chocoC *choco = malloc(sizeof(chocoC));
                    choco->id = ++cIDc;
                    choco->finishedSteps = 3;
                    for (int i = 0; i < 5; i++) {
                        if( i < 3) {
                            choco->steps[i] = 1;
                        }
                        else{
                            choco->steps[i] = 0;
                        }
                        
                    }
                    addToMemC(choco, line);
                    C_steps[line][prev_id]--;
                    // printf("thread C of line %d, emp %d sleep %d\n",line,id,dur);
                    // fflush(stdout);
                    sleep(dur);
                    pthread_mutex_unlock(&Cmemory_mutex[line]);
                }
                pthread_mutex_unlock(&mutex_typeC[line][prev_id]);
            }
            else{
                pthread_mutex_lock(&Cmemory_mutex[line]);
                chocoC *choco = getFromMemC(id, line);
                pthread_mutex_unlock(&Cmemory_mutex[line]);
                if (choco!=NULL){
                    choco->steps[id] = 1;
                    choco->finishedSteps++;
                    int dur = (int) (a[0] + (rand() % (a[1] - a[0])));
                    // printf("thread C of line %d, emp %d sleep %d, steps %d\n",line,id,dur,choco->finishedSteps);
                    // fflush(stdout);
                    sleep(dur);
                    if (choco->finishedSteps == 5) {
                        C_prod++;
                        printf("choco C produced from line %d\n",line);
                        fflush(stdout);
                    }
                    else {
                        pthread_mutex_lock(&Cmemory_mutex[line]);
                        addToMemC(choco, line);
                        pthread_mutex_unlock(&Cmemory_mutex[line]);
                    } 
                }
                
            }
        }
    }
}

void collect_choco(int *data){
    while(1){ 
        if (A_prod > 10){
            pthread_mutex_lock(&collect_choco_mutex);
            A_prod=A_prod-10;
            A_patch=A_patch+1;
            pthread_mutex_unlock(&collect_choco_mutex);
            printf("produced patch %d for A\n",A_patch);
            sleep(2);
        }
        if (B_prod > 10){
            pthread_mutex_lock(&collect_choco_mutex);
            B_prod=B_prod-10;
            B_patch=B_patch+1;
            pthread_mutex_unlock(&collect_choco_mutex);
            printf("produced patch %d for B\n",B_patch);
            sleep(2);
        }
        if (C_prod > 10){
            pthread_mutex_lock(&collect_choco_mutex);
            C_prod=C_prod-10;
            C_patch=C_patch+1;
            pthread_mutex_unlock(&collect_choco_mutex);
            printf("produced patch %d for C\n",C_patch);
            sleep(2);
        }
    }
}

void expiry(int *data){
    while(1){ 
        if (A_patch >= 1){
            pthread_mutex_lock(&expiry_mutex);
            A_patch=A_patch-1;
            A_patch_p = A_patch_p + 1;
            pthread_mutex_unlock(&expiry_mutex);
            sleep(1);
            printf("produced patch with date %d for A\n",A_patch_p); 
        }
        if (B_patch >= 1){
            pthread_mutex_lock(&expiry_mutex);
            B_patch=B_patch-1;
            B_patch_p = B_patch_p +1;
            pthread_mutex_unlock(&expiry_mutex);
            sleep(1);
            printf("produced patch with date %d for B\n",B_patch_p); 
        }
        if (C_patch >= 1){
            pthread_mutex_lock(&expiry_mutex);
            C_patch=C_patch-1;
            C_patch_p = C_patch_p +1;
            pthread_mutex_unlock(&expiry_mutex);
            sleep(1);
            printf("produced patch with date %d for B\n",C_patch_p); 
        }
    }
}

void fill_containers(int *data){
        while(1){ 
        if (A_patch_p >= 1){
            pthread_mutex_lock(&containers_mutex);
            A_patch_p=A_patch_p-1;
            A_containers = A_containers + 10;
            pthread_mutex_unlock(&containers_mutex);
            sleep(1);
            printf("filled container %d for A\n",A_containers); 
        }
        if (B_patch_p >= 1){
            pthread_mutex_lock(&containers_mutex);
            B_patch_p=B_patch_p-1;
            B_containers = B_containers +10;
            pthread_mutex_unlock(&containers_mutex);
            sleep(1);
            printf("filled container %d for B\n",B_containers); 
        }
        if (C_patch_p >= 1){
            pthread_mutex_lock(&containers_mutex);
            C_patch_p=C_patch_p-1;
            C_containers = C_containers +10;
            pthread_mutex_unlock(&containers_mutex);
            sleep(1);
            printf("filled container %d for C\n",C_containers); 
        }
    }
}

void fill_cartons(int *data){
    int x = *(int *)data;
    //printf("x = %d\n",x);
    while(1){
        sleep(1);
        if (x == 0){
            //A_C += A_patch_p;
            //A_patch_p = 0;
            if ( A_containers >= 20){
                pthread_mutex_lock(&fill_cartons_mutex);
                A_cartons++;
                A_C += A_containers;
                A_containers = A_containers - 20;
                pthread_mutex_unlock(&fill_cartons_mutex);
                printf("employee %d in cartons filled A cartons, current %d\n",x,A_cartons);
            }
        }
        else if (x == 1){
            //B_C += B_patch_p;
            //B_patch_p = 0;
            if ( B_containers >= 20){
                pthread_mutex_lock(&fill_cartons_mutex);
                B_cartons++;
                B_C += B_containers;
                B_containers = B_containers - 20;
                pthread_mutex_unlock(&fill_cartons_mutex);
                printf("employee %d in cartons filled B cartons, current %d\n",x,B_cartons);
            }
        }
        else if (x == 2){
            //C_C += C_patch_p;
            //C_patch_p = 0;
            if ( C_containers >= 20){
                pthread_mutex_lock(&fill_cartons_mutex);
                C_cartons++;
                C_C += C_containers;
                C_containers = C_containers - 20;
                pthread_mutex_unlock(&fill_cartons_mutex);
                printf("employee %d in cartons filled C cartons, current %d\n",x,C_cartons);
            }
        }
    }
}

void store_cartons(int *data){
    while(1){
        if (storage_flag == 0){
            if (A_cartons  > 0 && A_storage + B_storage + C_storage <= a[7]){
                pthread_mutex_lock(&store_cartons_mutex);
                A_storage++;
                A_cartons--;
                pthread_mutex_unlock(&store_cartons_mutex);
                printf("carton A was added to storage A, current in A storage %d, current in A cartons %d\n",A_storage,A_cartons);
                sleep(a[8]);
            }
            if (B_cartons > 0 && A_storage + B_storage + C_storage <= a[7]){
                pthread_mutex_lock(&store_cartons_mutex);
                B_storage++;
                B_cartons--;
                pthread_mutex_unlock(&store_cartons_mutex);
                printf("carton B was added to storage B, current in B storage %d, current in B cartons %d\n",B_storage,B_cartons);
                sleep(a[8]);
            }
            if (C_cartons > 0  && A_storage + B_storage + C_storage <= a[7]){
                pthread_mutex_lock(&store_cartons_mutex);
                C_storage++;
                C_cartons--;
                pthread_mutex_unlock(&store_cartons_mutex);
                printf("carton C was added to storage C, current in C storage %d, current in C cartons %d\n",C_storage,C_cartons);
                sleep(a[8]);
            }
            if (A_storage + B_storage + C_storage > a[7]){
                suspend = 1;
                storage_flag = 1;
                printf("suspend\n");
            }
        }
        if ( A_storage + B_storage + C_storage <= a[6] && storage_flag ==1 ){
            storage_flag = 0;
            suspend = 0;
            printf("unsuspend\n");
        }
    }
}

void fill_trucks(int *data){
    while(1){
        if(t1_f==0 && s1 == 1){
            pthread_mutex_lock(&fill_truck_mutex);
            if (A_truck < a[9] && A_storage > 0){
                A_truck++;
                A_storage--;
                sleep(1);
            }
            pthread_mutex_unlock(&fill_truck_mutex);
            pthread_mutex_lock(&fill_truck_mutex);
            if (B_truck < a[10] && B_storage > 0){
                B_truck++;
                B_storage--;
                sleep(1);
            }
            pthread_mutex_unlock(&fill_truck_mutex);
            pthread_mutex_lock(&fill_truck_mutex);
            if (C_truck < a[11] && C_storage > 0){
                C_truck++;
                C_storage--;
                sleep(1);
            }
            pthread_mutex_unlock(&fill_truck_mutex);
            if ( C_truck == a[11] && B_truck == a[10] && A_truck == a[9]){
                A_final+=A_truck;
                B_final+=B_truck;
                C_final+=C_truck;
                A_truck=0;
                B_truck=0;
                C_truck=0;
                printf("truck 1 departed\n");
                printf("A_truck %d, B_truck %d, C_truck %d, A_final = %d, B_final = %d, C_final = %d\n",A_truck,B_truck,C_truck,A_final,B_final,C_final);
                t1_f=1;
                s1=0;//change prio
                s2=1;
                s3=0;
            }
        }
        else if (t2_f==0 && s2 == 1){
            pthread_mutex_lock(&fill_truck_mutex);
            if (A_truck < a[9] && A_storage > 0){
                A_truck++;
                A_storage--;
                sleep(1);
            }
            pthread_mutex_unlock(&fill_truck_mutex);
            pthread_mutex_lock(&fill_truck_mutex);
            if (B_truck < a[10] && B_storage > 0){
                B_truck++;
                B_storage--;
                sleep(1);
            }
            pthread_mutex_unlock(&fill_truck_mutex);
            pthread_mutex_lock(&fill_truck_mutex);
            if (C_truck < a[11] && C_storage > 0){
                C_truck++;
                C_storage--;
                sleep(1);
            }
            pthread_mutex_unlock(&fill_truck_mutex);
            if ( C_truck == a[11] && B_truck == a[10] && A_truck == a[9]){
                A_final+=A_truck;
                B_final+=B_truck;
                C_final+=C_truck;
                A_truck=0;
                B_truck=0;
                C_truck=0;
                printf("truck 2 departed\n");
                printf("A_truck %d, B_truck %d, C_truck %d, A_final = %d, B_final = %d, C_final = %d\n",A_truck,B_truck,C_truck,A_final,B_final,C_final);
                t2_f=1;
                s1=0;
                s2=0;
                s3=1;
            }
        }
        else if (t3_f==0 && s3 == 1){
            pthread_mutex_lock(&fill_truck_mutex);
            if (A_truck < a[9] && A_storage > 0){
                A_truck++;
                A_storage--;
                sleep(1);
            }
            pthread_mutex_unlock(&fill_truck_mutex);
            pthread_mutex_lock(&fill_truck_mutex);
            if (B_truck < a[10] && B_storage > 0){
                B_truck++;
                B_storage--;
                sleep(1);
            }
            pthread_mutex_unlock(&fill_truck_mutex);
            pthread_mutex_lock(&fill_truck_mutex);
            if (C_truck < a[11] && C_storage > 0){
                C_truck++;
                C_storage--;
                sleep(1);
            }
            pthread_mutex_unlock(&fill_truck_mutex);
            if ( C_truck == a[11] && B_truck == a[10] && A_truck == a[9]){
                A_final+=A_truck;
                B_final+=B_truck;
                C_final+=C_truck;
                A_truck=0;
                B_truck=0;
                C_truck=0;
                printf("truck 3 departed\n");
                printf("A_truck %d, B_truck %d, C_truck %d, A_final = %d, B_final = %d, C_final = %d\n",A_truck,B_truck,C_truck,A_final,B_final,C_final);
                t3_f=1;
                s1=1;
                s2=0;
                s3=0;
            }
        }
    }
}

void truck(int *data){//go away for time
    int z = *(int *)data;
    while(1){
        if (z==0){
            if(t1_f == 1){
                sleep(a[12]);
                t1_f=0;
            }
        }
        else if (z==1){
            if(t2_f == 1){
                sleep(a[12]);
                t2_f=0;
            }
        }
        else if (z==2){
            if(t3_f == 1){
                sleep(a[12]);
                t3_f=0;
            }
        }
    }
}



void create_shm(){
    ipc_key = ftok(".", 'C');
    if ( (shmid_open = shmget( ipc_key, sizeof(int)*22, IPC_CREAT | 0666)) < 0 ) {
        perror("shmget fail");
        exit(1);
    }

    if ( (var = (int *) shmat(shmid_open, 0, 0)) == (int *) -1 ) {
        perror("shmat: fail");
        exit(2);
    }

    

}


void open_thread(int *date){
    while(1){
        var[0]=A_prod;
        var[1]=B_prod;
        var[2]=C_prod;

        var[3]=A_patch_p+B_patch_p+C_patch_p;
        // var[4]=B_patch_p;
        // var[5]=C_patch_p;

        var[6]=A_containers;
        var[7]=B_containers;
        var[8]=C_containers;

        var[9]=A_cartons;
        var[10]=B_cartons;
        var[11]=C_cartons;

        var[12]=A_storage;
        var[13]=B_storage;
        var[14]=C_storage;

        var[15]=t1_f;
        var[16]=t2_f;
        var[17]=t3_f;

        var[18]=A_final;
        var[19]=B_final;
        var[20]=C_final;

        var[21]=suspend;

        int k=0;
        if(s1==1){
            k=1;
        }
        else if (s2==1){
            k=2;
        }
       else if (s3==1){
            k=3;
        }
        var[4]=k;
        
    }


}


