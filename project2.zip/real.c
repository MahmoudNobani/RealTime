#include "local.h"

char temp [20];
char temp1 [20];

int flag=0;

char F[] = "F";
char M[] = "M";

int c=20;
int timing=1;
int officer,metal_officer,wait_size,teller1,teller2,teller3,teller4,openGL;
int removed_id[100],size_rem=0;


void create_shm(int *,int *);
void delete_one_initial_queue(int);
void arrive(int,int);
void delete_random_initial_queue();
void remove_alot_initial_queue();
void update_size(int,int);
void kill_all_persons();
void add_to_q_flag();


int main(void)
{

    void sigset_catcherA(int);
    void sigset_catcherB(int);

    sigset(SIGUSR1, sigset_catcherA);
    sigset(SIGUSR2, sigset_catcherB);



    read_param();
    int males[a[7]],females[a[7]];
    printf("a[8]=%d\n",a[8]);
    wait_size=a[8];
    //wait_val[0]=a[8];


    //males_values[0]=a[7];
    //females_values[0]=a[7];

    //create shm + semaphores
    //make shared memory for the the different comms used
    create_shm(males,females);
    thresh[0]=0;
    thresh[1]=0;
    thresh[2]=0;
    //printf("semid_size=%d\n",semid_size);
    //printf("semid_person=%d\n",semid_person);

    printf("sh size=%d, person=%d, males=%d, females=%d, comms=%d, thresh=%d, wait%d\n",shmid_size,shmid_person,shmid_males,shmid_females,shmid_comms,shmid_thresh,shmid_wait);
    printf("sem size=%d, person=%d, males=%d, females=%d, comms=%d, thresh=%d, wait%d\n",semid_size,semid_person,semid_males,semid_females,semid_comms,semid_thresh,semid_wait);

    

    sleep(1);
    //read parameters from file



    //initial arrival
    current = current_time();
    //printf("time now = %ld\n", current);
    printf("random initial arrival\n");
    close_sem(semid_person);
    close_sem(semid_size);
    sleep(5);
    arrive(10,15);
    size[0]=size_counter;
    open_sem(semid_person);
    open_sem(semid_size);
    //sleep(10);
    add_to_q_flag();
    sleep(2);

//start time counting
    initial = current_time();
    printf("initial time = %ld\n", initial);

    //fork officer and metal officer
    officer = fork();
    sprintf(temp,"%d",0);
    if( officer == 0){
        execlp("./officer", "officer",temp, (char *) NULL);
    }

    metal_officer = fork();
    sprintf(temp,"%d",1);
    if( metal_officer == 0){
        execlp("./officer", "officer",temp, (char *) NULL);
    }

    
    sleep(1);

    //start simulation
    printf("\nstart simulation\n");
    //print all in first queue
    close_sem(semid_person);
    close_sem(semid_size);
    for( int i = 0; i < size[0]; i++){
        printf("people[%d] => id = %d, gender = %c, permit = %d\n",i,initial_person_shm[i].id,initial_person_shm[i].MF,initial_person_shm[i].permit);
    }
    open_sem(semid_person);
    open_sem(semid_size);

    //delete random person
    close_sem(semid_person);
    close_sem(semid_size);
    delete_random_initial_queue();
    size[0]=size_counter;
    open_sem(semid_person);
    open_sem(semid_size);

    openGL = fork();
    if( openGL == 0){
        execlp("./openGL", "openGL",(char *) NULL);
    }


    //divide into males femlaes queue
    printf("sizex=%d\n",size[0]);
    kill(officer,SIGUSR1);
    sleep(1);

    //print males, females
    close_sem(semid_size);
    close_sem(semid_males);
    close_sem(semid_females);
    printf("print females:\n");
    print_elements(females_q,size[1]);
    printf("print males:\n");
    print_elements(males_q,size[2]);
    open_sem(semid_size);
    open_sem(semid_males);
    open_sem(semid_females);

    //print who is left
    close_sem(semid_person);
    for( int i = 0; i < size[0]; i++){
        printf("people[%d] => id = %d, gender = %c, permit = %d\n",i,initial_person_shm[i].id,initial_person_shm[i].MF,initial_person_shm[i].permit);
    }
    open_sem(semid_person);


    //create the 4 tellers
    teller1 = fork();
    sprintf(temp,"%d",1);
    if( teller1 == 0){
        execlp("./teller", "teller",temp, (char *) NULL);
    }
    sleep(1);
    teller2 = fork();
    sprintf(temp,"%d",2);
    if( teller2 == 0){
        execlp("./teller", "teller",temp, (char *) NULL);
    }
    sleep(1);
    teller3 = fork();
    sprintf(temp,"%d",3);
    if( teller3 == 0){
        execlp("./teller", "teller",temp, (char *) NULL);
    }
    sleep(1);
    teller4 = fork();
    sprintf(temp,"%d",4);
    if( teller4 == 0){
        execlp("./teller", "teller",temp, (char *) NULL);
    }
    sleep(1);


    //add to waitroom
    for ( int i = 0; i<wait_size-1; i++){
        printf("in above while, wait size=%d, i=%d\n",wait_size,i);
        kill(metal_officer,SIGUSR1);
        sleep(2);
    }
    
    //unpause the teller, they start working
    kill(teller1,SIGUSR1);
    kill(teller2,SIGUSR1);
    kill(teller3,SIGUSR1);
    kill(teller4,SIGUSR1);



while(flag == 0){

    printf("\nin while\n\n");

    //add to waitroom
    kill(metal_officer,SIGUSR1);
    sleep(2);

    //print male and female
    close_sem(semid_size);
    close_sem(semid_males);
    close_sem(semid_females);
    printf("print females:\n");
    print_elements(females_q,size[1]);
    printf("print males:\n");
    print_elements(males_q,size[2]);
    open_sem(semid_size);
    open_sem(semid_males);
    open_sem(semid_females);

    //people arrival from 8-1
    if ( (int) current_time() >= initial+c && timing == 1){
        close_sem(semid_person);
        close_sem(semid_size);
        size_counter=size[0];
        sleep(5);
        arrive(1,5);
        size[0]=size_counter;
        open_sem(semid_person);
        open_sem(semid_size);
        sleep(2);
        kill(officer,SIGUSR1);
        sleep(2);
        c+=20;
        if(c == 100){
            timing=0;
        }
        
    }

    //print all
    close_sem(semid_person);
    for( int i = 0; i < size[0]; i++){
        printf("people[%d] => id = %d, gender = %c, permit = %d\n",i,initial_person_shm[i].id,initial_person_shm[i].MF,initial_person_shm[i].permit);
    }
    open_sem(semid_person);
    sleep(2);
}   


    sleep(4);

    kill(teller1,SIGKILL);
    kill(teller2,SIGKILL);
    kill(teller3,SIGKILL);
    kill(teller4,SIGKILL);
    kill(officer,SIGKILL);
    kill(metal_officer,SIGKILL);

    sleep(2);
    kill_all_persons();

    printf("\n\n unserved = %d, unhappy = %d, satisfied = %d\n",thresh[0],thresh[1],thresh[2]);

    shmdt(size);
    shmctl(shmid_size, IPC_RMID, (struct shmid_ds *) 0);

    shmdt(initial_person_shm);
    shmctl(shmid_person, IPC_RMID, (struct shmid_ds *) 0);

    shmdt(males_q);
    shmctl(shmid_males, IPC_RMID, (struct shmid_ds *) 0);

    shmdt(females_q);
    shmctl(shmid_females, IPC_RMID, (struct shmid_ds *) 0);

    shmdt(thresh);
    shmctl(shmid_thresh, IPC_RMID, (struct shmid_ds *) 0);

    shmdt(comms);
    shmctl(shmid_comms, IPC_RMID, (struct shmid_ds *) 0);

    shmdt(waitroom);
    shmctl(shmid_wait, IPC_RMID, (struct shmid_ds *) 0);

    if ( semctl(semid_size, 0, IPC_RMID, 0) == -1 ) {
      perror("semctl -- producer");
    }

    if ( semctl(semid_comms, 0, IPC_RMID, 0) == -1 ) {
      perror("semctl -- producer");
    }

    if ( semctl(semid_thresh, 0, IPC_RMID, 0) == -1 ) {
      perror("semctl -- producer");
    }

    if ( semctl(semid_wait, 0, IPC_RMID, 0) == -1 ) {
      perror("semctl -- producer");
    }

    if ( semctl(semid_person, 0, IPC_RMID, 0) == -1 ) {
      perror("semctl -- producer");
      
    }

    if ( semctl(semid_males, 0, IPC_RMID, 0) == -1 ) {
      perror("semctl -- producer");
    }

    if ( semctl(semid_females, 0, IPC_RMID, 0) == -1 ) {
      perror("semctl -- producer");
      
    }

    exit(6);

    while(1);
    
}






void add_to_q_flag(){
    close_sem(semid_person);
    close_sem(semid_size);
    for (int i=0; i<size[0]; i++){
        kill(initial_person_shm[i].id,SIGUSR1);
    }
    open_sem(semid_person);
    open_sem(semid_size);
}

void kill_all_persons(){
    close_sem(semid_person);
    close_sem(semid_size);
    close_sem(semid_males);
    close_sem(semid_females);
    close_sem(semid_wait);
    for (int i=0; i<size[0]; i++){
        kill(initial_person_shm[i].id,SIGKILL);
    }
    for (int i=0; i<size[1]; i++){
        kill(females_q[i],SIGKILL);
    }
    for (int i=0; i<size[2]; i++){
        kill(males_q[i],SIGKILL);
    }
    for (int i=0; i<size[3]; i++){
        kill(waitroom[i],SIGKILL);
    }
    open_sem(semid_person);
    open_sem(semid_size);
    open_sem(semid_males);
    open_sem(semid_females);
    open_sem(semid_wait);
}

void remove_alot_initial_queue(){
    for (int i=0;i<size_rem;i++){
        delete_one_initial_queue(removed_id[i]);
        removed_id[i]=0;
    }
    size_rem=0;
}

void update_size(int pos, int x){
    acquire.sem_num = 0;
    if ( semop(semid_size, &acquire, 1) == -1 ) {
        perror("semop -- producer -- waiting for other to stop operation");}
    size[pos]=x;
    release.sem_num = 0;
    if ( semop(semid_size, &release, 1) == -1 ) {
        perror("semop -- producer -- waiting for other to stop operation");}
}

void sigset_catcherA(int n)
{
    flag=1;
}

void sigset_catcherB(int n)
{
    printf("recived the end signal\n");
}

void arrive(int min, int max){
    srand((unsigned) time(&t) + getpid());
    int dur = (int) (min + (rand() % (max))); //calculate duration
    int p;

    for (int i = 0; i < dur; i++) {
        people[size_counter] = fork();
        if (people[size_counter] == -1){
            perror("fork error");
        }
        if (people[size_counter] == 0){
            srand((unsigned) time(&t) + getpid());
            initial_person_shm[size_counter].id=getpid();
            int MF = (int) (rand()%100); //calculate rand
            if (MF%2 == 0){
                initial_person_shm[size_counter].MF ='F';
                srand((unsigned) time(&t) + getpid());
                p = (int) (1 + (rand() % (4))); //calculate duration
                initial_person_shm[size_counter].permit = p;
                //printf("null = %s\n", F);
                printf("people[%d] => id = %d, gender = %s, permit = %d\n",i,getpid(),F,p);
                sprintf(temp1,"%d",p);
                sprintf(temp,"%d",1);
                //printf("will perform exec now\n");
                execlp("./person", "person",temp1,temp,(char *) NULL);
            }
            else{
                initial_person_shm[size_counter].MF ='M';
                srand((unsigned) time(&t) + getpid());
                p = (int) (1 + (rand() % (4))); //calculate duration
                initial_person_shm[size_counter].permit = p;
                //sprintf(temp,"%c",'M');
                printf("people[%d] => id = %d, gender = %s, permit = %d\n",i,getpid(),M,p);
                sprintf(temp1,"%d",p);
                sprintf(temp,"%d",0);
                //printf("will perform exec now\n");
                execlp("./person", "person",temp1,temp,(char *) NULL);
            }     
        }
        size_counter++;
        sleep(2);
    }
}

void delete_random_initial_queue(){
    srand((unsigned) time(&t) + getpid());
    int pos = (int) (rand() % (size_counter)); //calculate random to remove
    printf("\n\nremove person in position %d\n\n",pos);
    for (int i = pos; i < size_counter-1; i++) {
        initial_person_shm[i] = initial_person_shm[i + 1];
    }
    // Decrease the size of the array
    size_counter--;
}

void delete_one_initial_queue(int pos){

    //printf("\n\nremove person in position %d\n\n",pos);
    for (int i = pos; i < size_counter-1; i++) {
        initial_person_shm[i] = initial_person_shm[i + 1];
    }
    initial_person_shm[size_counter-1].id = 0;
    initial_person_shm[size_counter-1].MF = '0';
    initial_person_shm[size_counter-1].permit = 0;
    // Decrease the size of the array
    size_counter--;
}

void create_shm(int *males, int *females){

    ipc_key = ftok(".", 'C');
    if ( (shmid_comms = shmget( ipc_key, sizeof(int), IPC_CREAT | 0666)) < 0 ) {
        perror("shmget fail for real comms");
        exit(1);
    }

    if ( (comms = (int *) shmat(shmid_comms, 0, 0)) == (int *) -1 ) {
        perror("shmat: for real comms");
        exit(2);
    }

    // create a semaphore for comms shm
    ipc_key = ftok(".", 'C');
    //printf("real ipc_key:%d\n", ipc_key);
    if ( (semid_comms = semget( ipc_key, 1,IPC_CREAT | 0666)) != -1 ) {
                arg.array = start_val;
    
        if ( semctl(semid_comms, 0, SETALL, arg) == -1 ) {
            perror("semctl -- parent -- initialization for real comms");
            exit(3);
        }
    }
    else {
        perror("semget -- parent -- creation for real comms");
        exit(4);
    }

    //make shared memory for the the different comms used
    ipc_key = ftok(".", 'W');
    printf("wait size =%d\n",wait_size);
    if ( (shmid_wait = shmget(ipc_key, sizeof(int)*wait_size, IPC_CREAT | 0666)) < 0 ) {
        perror("shmget fail for real wait");
        exit(1);
    }

    if ( (waitroom = (int *) shmat(shmid_wait, 0, 0)) == (int *) -1 ) {
        perror("shmat: for real wait");
        exit(2);
    }

    // create a semaphore for comms shm
    ipc_key = ftok(".", 'W');
    //printf("real ipc_key:%d\n", ipc_key);
    if ( (semid_wait = semget(ipc_key, 1,IPC_CREAT | 0666)) != -1 ) {
                arg.array = start_val;
    
        if ( semctl(semid_wait, 0, SETALL, arg) == -1 ) {
            perror("semctl -- parent -- initialization for real wait");
            exit(3);
        }
    }
    else {
        perror("semget -- parent -- creation for real wait");
        exit(4);
    }

    //make shared memory for the the threshhold counter used
    ipc_key = ftok(".", 'T');
    if ( (shmid_thresh = shmget(ipc_key, sizeof(int)*4, IPC_CREAT | 0666)) < 0 ) {
        perror("shmget fail for real threshold");
        exit(1);
    }

    if ( (thresh = (int *) shmat(shmid_thresh, 0, 0)) == (int *) -1 ) {
        perror("shmat: for real threshold");
        exit(2);
    }

    // create a semaphore for thresholds shm
    ipc_key = ftok(".", 'T');
    //printf("real ipc_key:%d\n", ipc_key);
    if ( (semid_thresh = semget( ipc_key, 1,IPC_CREAT | 0666)) != -1 ) {
                arg.array = start_val;
    
        if ( semctl(semid_thresh, 0, SETALL, arg) == -1 ) {
            perror("semctl -- parent -- initialization for real threshold");
            exit(3);
        }
    }
    else {
        perror("semget -- parent -- creation for real threshold");
        exit(4);
    }

    //make shared memory for the the different sizes used
    ipc_key = ftok(".", 'S');
    if ( (shmid_size = shmget(ipc_key, sizeof(int)*3, IPC_CREAT | 0666)) < 0 ) {
        perror("shmget fail for real size");
        exit(1);
    }

    if ( (size = (int *) shmat(shmid_size, 0, 0)) == (int *) -1 ) {
        perror("shmat: for real size");
        exit(2);
    }

    // create a semaphore for size shm
    ipc_key = ftok(".", 'S');
    //printf("real ipc_key:%d\n", ipc_key);
    if ( (semid_size = semget(ipc_key, 1,IPC_CREAT | 0666)) != -1 ) {
                arg.array = start_val;
    
        if ( semctl(semid_size, 0, SETALL, arg) == -1 ) {
            perror("semctl -- parent -- initialization for real size");
            exit(3);
        }
    }
    else {
        perror("semget -- parent -- creation for real size");
        exit(4);
    }

    //make shared memory for the person first queue
    ipc_key = ftok(".", 14369);
    if ( (shmid_person = shmget(ipc_key, sizeof(struct person)*100, IPC_CREAT | 0666)) < 0 ) {
        perror("shmget fail for real person");
        exit(1);
    }

    if ( (initial_person_shm = (struct person *) shmat(shmid_person, 0, 0)) == (struct person *) -1 ) {
        perror("shmat: for real person");
        exit(2);
    }

    // create a semaphore for person shm
    ipc_key = ftok(".", 14369);
    if ( (semid_person = semget(ipc_key, 1,IPC_CREAT | 0666)) != -1 ) {
                arg.array = start_val;
    
        if ( semctl(semid_person, 0, SETALL, arg) == -1 ) {
            perror("semctl -- real -- initialization -- person");
            exit(3);
        }
    }
    else {
        perror("semget -- real -- creation -- person");
        exit(4);
    }

    //build males queue:
    ipc_key = ftok(".", 'M');
    if ( (shmid_males = shmget(ipc_key, sizeof(males), IPC_CREAT | 0666)) < 0 ) {
        perror("shmat: parent for real male queue");
        exit(1);
    }

    if ( (males_q = (int *) shmat(shmid_males, 0, 0)) == (int *) -1 ) {
        perror("shmat: parent attach for real male queue");
        exit(2);
    }

    // create a semaphore for males shm
    ipc_key = ftok(".", 'M');
    if ( (semid_males = semget(ipc_key, 1,IPC_CREAT | 0666)) != -1 ) {
                arg.array = start_val;
    
        if ( semctl(semid_males, 0, SETALL, arg) == -1 ) {
            perror("semctl -- real -- initialization -- males queue");
            exit(3);
        }
    }
    else {
        perror("semget -- real -- creation -- males queue");
        exit(4);
    }

    //build females:
    ipc_key = ftok(".", 'F');
    if ( (shmid_females = shmget(ipc_key, sizeof(females), IPC_CREAT | 0666)) < 0 ) {
        perror("shmat: parent for real female queue");
        exit(1);
    }

    if ( (females_q = (int *) shmat(shmid_females, 0, 0)) == (int *) -1 ) {
        perror("shmat: parent attach for real female queue");
        exit(2);
    }

    // create a semaphore for females shm
    ipc_key = ftok(".", 'F');
    if ( (semid_females = semget( ipc_key, 1,IPC_CREAT | 0666)) != -1 ) {
                arg.array = start_val;
    
        if ( semctl(semid_females, 0, SETALL, arg) == -1 ) {
            perror("semctl -- real -- initialization -- females queue");
            exit(3);
        }
    }
    else {
        perror("semget -- real -- creation -- females queue");
        exit(4);
    }

}




