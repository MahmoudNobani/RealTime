#include "local.h"



int c = 10;
time_t t;
int flag=0;

int removed_id[100],size_rem=0;
int permits[100],p_size=0;

void remove_alot_initial_queue();
void delete_one_initial_queue(int pos);
void add_to_queue();
void delete_one_M_queue();
void delete_one_F_queue();
void get_all_permits();
void check_thresh();
int permit;
int wait_size;
int wait_counter;
void delete_one_wait_queue(int);

int main(int argc, char *argv[ ])
{
  
    void sigset_catcherA(int);
    void sigset_catcherB(int);

    sigset(SIGUSR1, sigset_catcherA);
    sigset(SIGUSR2, sigset_catcherB);

    permit = atoi(argv[1]);
    //printf("teller permit %d\n",permit);

    initial = current_time();
    //printf("initial time = %ld\n", initial);

    read_param();
    int males[a[7]],females[a[7]];
    wait_size=a[8];
    //make shared memory for the the different sizes used
    ipc_key = ftok(".", 'S');
    if ( (shmid_size = shmget(ipc_key, 0, 0)) < 0 ) {
        perror("shmget fail for size in officer");
        exit(1);
    }

    if ( (size = (int *) shmat(shmid_size, 0, 0)) == (int *) -1 ) {
        perror("shmat: attach for size in officer");
        exit(2);
    }

    //make shared memory for the person first queue
    ipc_key = ftok(".", 14369);
    if ( (shmid_person = shmget(ipc_key, 0, 0)) < 0 ) {
        perror("shmget for person in officer");
        exit(1);
    }

    if ( (initial_person_shm = (struct person *) shmat(shmid_person, 0, 0)) == (struct person *) -1 ) {
        perror("shmat attach for person in officer ");
        exit(2);
    }
    
    //make shared memory for the the waitroom used
    ipc_key = ftok(".", 'W');
    if ( (shmid_wait = shmget(ipc_key, 0, IPC_CREAT | 0666)) < 0 ) {
        perror("shmget fail for real wait");
        exit(1);
    }

    if ( (waitroom = (int *) shmat(shmid_wait, 0, 0)) == (int *) -1 ) {
        perror("shmat: for real wait");
        exit(2);
    }


    //make shared memory for the the different comms used
    ipc_key = ftok(".", 'C');
    if ( (shmid_comms = shmget(ipc_key, 0, IPC_CREAT | 0666)) < 0 ) {
        perror("shmget fail for person comms");
        exit(1);
    }

    if ( (comms = (int *) shmat(shmid_comms, 0, 0)) == (int *) -1 ) {
        perror("shmat: for person comms");
        exit(2);
    }

    //make shared memory for the the threshhold counter used
    ipc_key = ftok(".", 'T');
    if ( (shmid_thresh = shmget(ipc_key, 0, IPC_CREAT | 0666)) < 0 ) {
        perror("shmget fail for person threshold");
        exit(1);
    }

    if ( (thresh = (int *) shmat(shmid_thresh, 0, 0)) == (int *) -1 ) {
        perror("shmat: for person threshold");
        exit(2);
    }
    
    //build males queue:
    ipc_key = ftok(".", 'M');
    if ( (shmid_males = shmget(ipc_key, 0, IPC_CREAT | 0666)) < 0 ) {
        perror("shmget fail for officer male queue");
        exit(1);
    }

    if ( (males_q = (int *) shmat(shmid_males, 0, 0)) == (int *) -1 ) {
        perror("shmat: parent attach for officer male queue");
        exit(2);
    }

    //build females:
    ipc_key = ftok(".", 'F');
    if ( (shmid_females = shmget(ipc_key, 0, IPC_CREAT | 0666)) < 0 ) {
        perror("shmget fail for officer female queue");
        exit(1);
    }

    if ( (females_q = (int *) shmat(shmid_females, 0, 0)) == (int *) -1 ) {
        perror("shmat: parent attach for officer female queue");
        exit(2);
    }





    // create a semaphore for wait shm
    ipc_key = ftok(".", 'W');
    int semid_wait = semget(ipc_key, 1, 0);  // Attach to the semaphore set  
    if (semid_wait == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }


    // create a semaphore for thresholds shm
    ipc_key = ftok(".", 'T');
    int semid_thresh = semget(ipc_key, 1, 0);  // Attach to the semaphore set  
    if (semid_thresh == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }


    ipc_key = ftok(".", 'S');
    //printf("officer ipc_key:%d\n", ipc_key);
    int semid_size = semget(ipc_key, 1, 0);  // Attach to the semaphore set  
    if (semid_size == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }
    //printf("officer semid_size=%d\n",semid_size);

    ipc_key = ftok(".", 14369);
    int semid_person = semget(ipc_key, 1, 0);  // Attach to the semaphore set  
    if (semid_person == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }
    //printf("semid_person=%d\n",semid_person);

    // create a semaphore for males shm
    ipc_key = ftok(".", 'M');
    int semid_males = semget(ipc_key, 1, 0);  // Attach to the semaphore set
    if (semid_males == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }

    // create a semaphore for females shm
    ipc_key = ftok(".", 'F');
    int semid_females = semget(ipc_key, 1, 0);  // Attach to the semaphore set
    if (semid_females == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }

 

    printf("inside teller\n");
    fflush(stdout);
    pause();
  while(1){
    if(permit==1){
        close_sem(semid_size);
        close_sem(semid_wait);
        
        wait_counter=size[3];
        get_all_permits();
        sleep(1);
        //printf("size3 = %d\n",wait_counter);
        for (int i = 0; i < wait_counter;i++){
            if(permits[i]==1){
                printf("in tellers1, id=%d, permit=%d\n",waitroom[i],permits[i]);
                fflush(stdout);
                kill(waitroom[i],SIGKILL);
                delete_one_wait_queue(i);
                flag=1;
                srand(time(NULL));
                int num = rand() % 3;
                if(num == 0){
                    thresh[0]++;
                    printf("unserved\n");
                    check_thresh();
                }
                else if(num == 1){
                    thresh[1]++;
                    printf("unhappy\n");
                    check_thresh();
                }
                else if(num == 2){
                    thresh[2]++;
                    printf("satisfied\n");
                    check_thresh();
                }
                break;
            }     
            
        }
        if (flag == 0){
            if(wait_counter!=0){
                printf("in tellers1 rand, id=%d, permit=%d\n",waitroom[0],permits[0]);
                fflush(stdout);
                kill(waitroom[0],SIGKILL);
                delete_one_wait_queue(0);
                srand(time(NULL));
                int num = rand() % 3;
                if(num == 0){
                    thresh[0]++;
                    printf("unserved\n");
                    check_thresh();
                }
                else if(num == 1){
                    thresh[1]++;
                    printf("unhappy\n");
                    check_thresh();
                }
                else if(num == 2){
                    thresh[2]++;
                    printf("satisfied\n");
                    check_thresh();
                }
            }
        }
        size[3]=wait_counter;
        open_sem(semid_size);
        open_sem(semid_wait);
        
        flag=0;
        srand(time(NULL));
        int num = rand() % 10 + 5;
        sleep(num);
    }
    else if(permit==2){
        close_sem(semid_size);
        close_sem(semid_wait);
        
        wait_counter=size[3];
        get_all_permits();
        sleep(1);
        //printf("size3 = %d\n",wait_counter);
        for (int i = 0; i < wait_counter;i++){
            if(permits[i]==2){
                printf("in tellers2 rand, id=%d, permit=%d\n",waitroom[i],permits[i]);
                fflush(stdout);
                kill(waitroom[i],SIGKILL);
                delete_one_wait_queue(i);
                flag=1;
                srand(time(NULL));
                int num = rand() % 3;
                if(num == 0){
                    thresh[0]++;
                    printf("unserved\n");
                    check_thresh();
                }
                else if(num == 1){
                    thresh[1]++;
                    printf("unhappy\n");
                    check_thresh();
                }
                else if(num == 2){
                    thresh[2]++;
                    printf("satisfied\n");
                    check_thresh();
                }
                break;
            }     
            
        }
        if (flag == 0){
            if(wait_counter!=0){
                printf("in tellers2 rand, id=%d, permit=%d\n",waitroom[0],permits[0]);
                fflush(stdout);
                kill(waitroom[0],SIGKILL);
                delete_one_wait_queue(0);
                srand(time(NULL));
                int num = rand() % 3;
                if(num == 0){
                    thresh[0]++;
                    printf("unserved\n");
                    check_thresh();
                }
                else if(num == 1){
                    thresh[1]++;
                    printf("unhappy\n");
                    check_thresh();
                }
                else if(num == 2){
                    thresh[2]++;
                    printf("satisfied\n");
                    check_thresh();
                }
            }
        }
        size[3]=wait_counter;
        open_sem(semid_size);
        open_sem(semid_wait);
        
        flag=0;
        srand(time(NULL));
        int num = rand() % 10 + 5;
        sleep(num);
    }
    else if(permit==3){
        close_sem(semid_size);
        close_sem(semid_wait);
        
        wait_counter=size[3];
        get_all_permits();
        sleep(1);
        //printf("size3 = %d\n",wait_counter);
        for (int i = 0; i < wait_counter;i++){
            if(permits[i]==3){
                printf("in tellers3 rand, id=%d, permit=%d\n",waitroom[i],permits[i]);
                fflush(stdout);
                kill(waitroom[i],SIGKILL);
                delete_one_wait_queue(i);
                flag=1;
                srand(time(NULL));
                int num = rand() % 3;
                if(num == 0){
                    thresh[0]++;
                    printf("unserved\n");
                    check_thresh();
                }
                else if(num == 1){
                    thresh[1]++;
                    printf("unhappy\n");
                    check_thresh();
                }
                else if(num == 2){
                    thresh[2]++;
                    printf("satisfied\n");
                    check_thresh();
                }
                break;
            }     
            
        }
        if (flag == 0){
            if(wait_counter!=0){
                printf("in tellers3 rand, id=%d, permit=%d\n",waitroom[0],permits[0]);
                fflush(stdout);
                kill(waitroom[0],SIGKILL);
                delete_one_wait_queue(0);
                srand(time(NULL));
                int num = rand() % 3;
                if(num == 0){
                    thresh[0]++;
                    printf("unserved\n");
                    check_thresh();
                }
                else if(num == 1){
                    thresh[1]++;
                    printf("unhappy\n");
                    check_thresh();
                }
                else if(num == 2){
                    thresh[2]++;
                    printf("satisfied\n");
                    check_thresh();
                }
            }
        }
        size[3]=wait_counter;
        open_sem(semid_size);
        open_sem(semid_wait);
        
        flag=0;
        srand(time(NULL));
        int num = rand() % 10 + 5;
        sleep(num);
 
    }
    else if(permit==4){
        close_sem(semid_size);
        close_sem(semid_wait);
        
        wait_counter=size[3];
        get_all_permits();
        sleep(1);
        //printf("size3 = %d\n",wait_counter);
        for (int i = 0; i < wait_counter;i++){
            if(permits[i]==4){
                printf("in tellers4 rand, id=%d, permit=%d\n",waitroom[i],permits[i]);
                fflush(stdout);
                kill(waitroom[i],SIGKILL);
                delete_one_wait_queue(0);
                flag=1;
                srand(time(NULL));
                int num = rand() % 3;
                if(num == 0){
                    thresh[0]++;
                    printf("unserved\n");
                    check_thresh();
                }
                else if(num == 1){
                    thresh[1]++;
                    printf("unhappy\n");
                    check_thresh();
                }
                else if(num == 2){
                    thresh[2]++;
                    printf("satisfied\n");
                    check_thresh();
                }
                break;
            }     
            
        }
        if (flag == 0){
            if(wait_counter!=0){
                printf("in tellers4 rand, id=%d, permit=%d\n",waitroom[0],permits[0]);
                fflush(stdout);
                kill(waitroom[0],SIGKILL);
                delete_one_wait_queue(0);
                srand(time(NULL));
                int num = rand() % 3;
                if(num == 0){
                    thresh[0]++;
                    printf("unserved\n");
                    check_thresh();
                }
                else if(num == 1){
                    thresh[1]++;
                    printf("unhappy\n");
                    check_thresh();
                }
                else if(num == 2){
                    thresh[2]++;
                    printf("satisfied\n");
                    check_thresh();
                }
            }
        }
        size[3]=wait_counter;
        open_sem(semid_size);
        open_sem(semid_wait);
        
        flag=0;
        srand(time(NULL));
        int num = rand() % 10 + 5;
        sleep(num);
 
    }

    }
}


void check_thresh(){
    if(thresh[0] >= a[0] || thresh[1] >= a[1] || thresh[2] >= a[2]){
        kill(getppid(),SIGUSR1);
    }
}

void get_all_permits(){

    // create a semaphore for comms shm
    ipc_key = ftok(".", 'C');
    int semid_comms = semget(ipc_key, 1, 0);  // Attach to the semaphore set  
    if (semid_comms == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }

    
    for ( int i = 0; i <  wait_counter; i++){
        kill(waitroom[i],SIGUSR2);
        sleep(1);
        close_sem(semid_comms);
        permits[i] = comms[0];
        open_sem(semid_comms);
        printf("permits we got from %d, is %d\n",permits[i],waitroom[i]);
    }
    
}

void add_to_queue(){

    for( int i = 0; i < size_counter; i++){
    printf("in exec whoile people[%d] => id = %d, gender = %c, permit = %d\n",i,initial_person_shm[i].id,initial_person_shm[i].MF,initial_person_shm[i].permit);
    fflush(stdout);
    if (initial_person_shm[i].MF == 'F'){
        if(females_counter < a[7]){
            females_q[females_counter]=initial_person_shm[i].id;
            removed_id[size_rem]=i;
            size_rem++;
            females_counter++;
            }
        }
    else{
        if(males_counter < a[7]){
            males_q[males_counter]=initial_person_shm[i].id;
            removed_id[size_rem]=i;
            size_rem++;
            males_counter++;
            } 
        }      
    }
    for(int i=0; i<size_rem; i++){
        printf("id=%d, %d\n",removed_id[i],initial_person_shm[removed_id[i]].id);
    }
}

void remove_alot_initial_queue(){
    
    for (int i=0;i<size_rem;i++){
        delete_one_initial_queue(removed_id[i]-i);
        removed_id[i]=0;
    }
    size_rem=0;
}

void delete_one_wait_queue(int pos){

    //printf("\n\nremove person in position %d\n\n",pos);
    for (int i = pos; i < wait_counter-1; i++) {
        waitroom[i] = waitroom[i + 1];
    }
    waitroom[wait_counter-1] = 0;
    // Decrease the size of the array
    wait_counter--;
}

void delete_one_F_queue(int pos){

    //printf("\n\nremove person in position %d\n\n",pos);
    for (int i = pos; i < females_counter-1; i++) {
        females_q[i] = females_q[i + 1];
    }
    females_q[females_counter-1] = 0;
    // Decrease the size of the array
    females_counter--;
}

void delete_one_initial_queue(int pos){

    //printf("\n\nremove person in position %d\n\n",pos);
    for (int i = pos; i < size_counter-1; i++) {
        initial_person_shm[i] = initial_person_shm[i + 1];
    }
    initial_person_shm[size_counter-1].id = 0;
    initial_person_shm[size_counter-1].MF = '0';
    initial_person_shm[size_counter-1].permit = 0;
    // Decrease the size of the array
    size_counter--;
}

void sigset_catcherA(int n)
{
    printf("unpauseing %d\n",permit);
}

void sigset_catcherB(int n)
{
    flag = 2;
}