gcc officer.c -o officer
gcc teller.c -o teller
gcc person.c -o person
gcc real.c -o real
gcc -g openGL.c -o openGL -lglut -lGLU -lGL -lm