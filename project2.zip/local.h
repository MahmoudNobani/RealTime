#ifndef __LOCAL_H_
#define __LOCAL_H_

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <time.h>
#include <wait.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <fcntl.h>

struct person *initial_person_shm;
pid_t pid;
key_t ipc_key;
int shmid_size,shmid_males,shmid_females,shmid_person,shmid_comms,shmid_thresh,shmid_wait;
int semid_person,semid_males,semid_females,semid_size,semid_comms,semid_thresh,semid_wait;
int *size,*males_q,*females_q,*comms,*thresh,*waitroom;
union semun    arg;
int size_counter=0;
int a[9];
time_t initial, current;
time_t t;
int people[100];
static unsigned short start_val[1] = {1};

void read_param();
time_t current_time();

void print_elements(int *array,int);
void open_sem(int id);
void close_sem(int id);


int males_counter = 0;
int females_counter = 0;

enum { DO, DONE };

union semun {
  int              val;
  struct semid_ds *buf;
  ushort          *array; 
};

static struct sembuf acquire = {0, -1, SEM_UNDO}, 
                     release = {0, 1, SEM_UNDO};

struct person{
    int id;
    char MF;
    int permit;
};


void close_sem(int id){
    acquire.sem_num = 0;
    if ( semop(id, &acquire, 1) == -1 ) {
        printf("\nacquire %d:\n",id);
        perror("semop -- producer -- waiting for other to stop operation");}
}

void open_sem(int id){
    release.sem_num = 0;
    if ( semop(id, &release, 1) == -1 ) {
        printf("\nrelease %d:\n",id);
        perror("semop -- producer -- waiting for other to stop operation");}
}

time_t current_time(){
    return time(NULL);
}

void read_param(){
    FILE* ptr;
	char ch[20];
    int y= 0;

	// Opening file in reading mode
	ptr = fopen("param.txt", "r");

    if (NULL == ptr) {
		printf("file can't be opened \n");
	}

    for ( int i = 0; i < 9; i++){

        fgets(ch,255,ptr);
        //printf("%s", ch);

        char * token = strtok(ch, "=");
        while (token != NULL) {
            //printf("%s\n",token);
            if(y==1){
                sprintf(ch,"%s",token);
                
            }
            token = strtok(NULL, "=");
            y++;
        }

        int x = atoi(ch);
        //printf("%d\n",x);
        a[i] = x;
        y=0;

    }

	// Closing the file
	fclose(ptr);
}

void print_elements(int *array, int size) {
        for (int i = 0; i < size; i++) {
        printf("array[%d], %d\n", i,array[i]);
    }
    printf("\n");
}


#endif
