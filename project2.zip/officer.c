#include "local.h"



int c = 10;

time_t t;
int flag=0;

int removed_id[100],size_rem=0;
int wait_counter=0;


void remove_alot_initial_queue();
void delete_one_initial_queue(int pos);
void add_to_queue();
void delete_one_M_queue();
void delete_one_F_queue();
int pos;
int wait_size;


int main(int argc, char *argv[ ])
{
  
    void sigset_catcherA(int);

    sigset(SIGUSR1, sigset_catcherA);

    pos = atoi(argv[1]);

    initial = current_time();
    printf("initial time = %ld\n", initial);

    read_param();
    int males[a[7]],females[a[7]];
    wait_size=a[8];
    //make shared memory for the the different sizes used
    ipc_key = ftok(".", 'S');
    if ( (shmid_size = shmget(ipc_key, 0, 0)) < 0 ) {
        perror("shmget fail for size in officer");
        exit(1);
    }

    if ( (size = (int *) shmat(shmid_size, 0, 0)) == (int *) -1 ) {
        perror("shmat: attach for size in officer");
        exit(2);
    }

    //make shared memory for the person first queue
    ipc_key = ftok(".", 14369);
    if ( (shmid_person = shmget(ipc_key, 0, 0)) < 0 ) {
        perror("shmget for person in officer");
        exit(1);
    }

    if ( (initial_person_shm = (struct person *) shmat(shmid_person, 0, 0)) == (struct person *) -1 ) {
        perror("shmat attach for person in officer ");
        exit(2);
    }
    
    //make shared memory for the the waitroom used
    ipc_key = ftok(".", 'W');
    if ( (shmid_wait = shmget(ipc_key, 0, IPC_CREAT | 0666)) < 0 ) {
        perror("shmget fail for real wait");
        exit(1);
    }

    if ( (waitroom = (int *) shmat(shmid_wait, 0, 0)) == (int *) -1 ) {
        perror("shmat: for real wait");
        exit(2);
    }


    //make shared memory for the the different comms used
    ipc_key = ftok(".", 'C');
    if ( (shmid_comms = shmget(ipc_key, 0, IPC_CREAT | 0666)) < 0 ) {
        perror("shmget fail for person comms");
        exit(1);
    }

    if ( (comms = (int *) shmat(shmid_comms, 0, 0)) == (int *) -1 ) {
        perror("shmat: for person comms");
        exit(2);
    }

    //make shared memory for the the threshhold counter used
    ipc_key = ftok(".", 'T');
    if ( (shmid_thresh = shmget(ipc_key, 0, IPC_CREAT | 0666)) < 0 ) {
        perror("shmget fail for person threshold");
        exit(1);
    }

    if ( (thresh = (int *) shmat(shmid_thresh, 0, 0)) == (int *) -1 ) {
        perror("shmat: for person threshold");
        exit(2);
    }
    
    //build males queue:
    ipc_key = ftok(".", 'M');
    if ( (shmid_males = shmget(ipc_key, 0, IPC_CREAT | 0666)) < 0 ) {
        perror("shmget fail for officer male queue");
        exit(1);
    }

    if ( (males_q = (int *) shmat(shmid_males, 0, 0)) == (int *) -1 ) {
        perror("shmat: parent attach for officer male queue");
        exit(2);
    }

    //build females:
    ipc_key = ftok(".", 'F');
    if ( (shmid_females = shmget(ipc_key, 0, IPC_CREAT | 0666)) < 0 ) {
        perror("shmget fail for officer female queue");
        exit(1);
    }

    if ( (females_q = (int *) shmat(shmid_females, 0, 0)) == (int *) -1 ) {
        perror("shmat: parent attach for officer female queue");
        exit(2);
    }


    // create a semaphore for comms shm
    ipc_key = ftok(".", 'C');
    int semid_comms = semget(ipc_key, 1, 0);  // Attach to the semaphore set  
    if (semid_comms == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }


    // create a semaphore for wait shm
    ipc_key = ftok(".", 'W');
    int semid_wait = semget(ipc_key, 1, 0);  // Attach to the semaphore set  
    if (semid_wait == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }


    // create a semaphore for thresholds shm
    ipc_key = ftok(".", 'T');
    int semid_thresh = semget(ipc_key, 1, 0);  // Attach to the semaphore set  
    if (semid_thresh == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }


    ipc_key = ftok(".", 'S');
    //printf("officer ipc_key:%d\n", ipc_key);
    int semid_size = semget(ipc_key, 1, 0);  // Attach to the semaphore set  
    if (semid_size == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }
    
    //printf("officer semid_size=%d\n",semid_size);

    ipc_key = ftok(".", 14369);
    int semid_person = semget(ipc_key, 1, 0);  // Attach to the semaphore set  
    if (semid_person == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }
    //printf("semid_person=%d\n",semid_person);

    // create a semaphore for males shm
    ipc_key = ftok(".", 'M');
    int semid_males = semget(ipc_key, 1, 0);  // Attach to the semaphore set
    if (semid_males == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }

    // create a semaphore for females shm
    ipc_key = ftok(".", 'F');
    int semid_females = semget(ipc_key, 1, 0);  // Attach to the semaphore set
    if (semid_females == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }

 
    

    printf("inside officer\n");
    fflush(stdout);

  while(1){
    if(flag == 1 && pos==0){//add from outer
        //add to initial queue
        close_sem(semid_person);
        close_sem(semid_size);
        close_sem(semid_males);
        close_sem(semid_females);
        size_counter = size[0];
        females_counter=size[1];
        males_counter=size[2];
        add_to_queue();
        size[1]=females_counter;
        size[2]=males_counter;
        open_sem(semid_person);
        open_sem(semid_size);
        open_sem(semid_males);
        open_sem(semid_females);

        close_sem(semid_person);
        close_sem(semid_size);
        remove_alot_initial_queue();
        size[0]=size_counter;
        size_rem=0;
        open_sem(semid_person);
        open_sem(semid_size);
        flag = 0; 
    }
    //metal detection
    srand((unsigned) time(&t) + getpid());
    int metal = (int) (rand()%100);
    if ( metal <= 1){
        sleep(1);
        if(metal%2 == 0){
            flag=0;
            printf("failed metal detection\n");
        }
    }   
    //take one from metal detector
    else if(flag == 1 && pos==1){

        close_sem(semid_person);
        close_sem(semid_size);
        close_sem(semid_males);
        close_sem(semid_females);
        close_sem(semid_wait);
        size_counter = size[0];
        females_counter=size[1];
        males_counter=size[2];
        wait_counter=size[3];
        srand((unsigned) time(&t) + getpid());
        int MF = (int) (rand()%100); 
        if ( MF%2 == 0 && females_counter > 0 && wait_counter < wait_size){
            kill(females_q[0],SIGUSR2);
            sleep(1);
            close_sem(semid_comms);
            int xy = comms[0];
            open_sem(semid_comms);
            printf("id = %d, permit = %d\n",females_q[0],xy);
            fflush(stdout);
            if(wait_counter < wait_size){
                waitroom[wait_counter]=females_q[0];
                wait_counter++;
                delete_one_F_queue(0);
                for(int i=0;i<size_counter;i++){
                    if (initial_person_shm[i].MF == 'F'){
                        females_q[females_counter]=initial_person_shm[i].id;
                        removed_id[size_rem]=i;
                        size_rem++;
                        //kill(females_q[females_counter],SIGUSR1);
                        females_counter++;
                        break;
                        } 
                    }
                    //kill(females_q[females_counter-1],SIGUSR1); 
                }
            }
        else if ( MF%2 == 1 && males_counter > 0 && wait_counter < wait_size){
            kill(males_q[0],SIGUSR2);
            sleep(1);
            close_sem(semid_comms);
            int xy = comms[0];
            open_sem(semid_comms);
            printf("id = %d, permit = %d\n",males_q[0],xy);
            fflush(stdout);
            if(wait_counter < wait_size){
                waitroom[wait_counter]=males_q[0];
                wait_counter++;
                delete_one_M_queue(0);
                for(int i=0;i<size_counter;i++){
                    if (initial_person_shm[i].MF == 'M'){
                        males_q[males_counter]=initial_person_shm[i].id;
                        removed_id[size_rem]=i;
                        size_rem++;
                        //kill(males_q[males_counter],SIGUSR1);
                        males_counter++;
                        break;
                        } 
                    }
                    //kill(males_q[males_counter-1],SIGUSR1); 
                }
            }
        else{
            if ( females_counter > 0 && wait_counter < wait_size ){
            kill(females_q[0],SIGUSR2);
            sleep(1);
            close_sem(semid_comms);
            int xy = comms[0];
            open_sem(semid_comms);
            printf("id = %d, permit = %d\n",females_q[0],xy);
            fflush(stdout);
            if(wait_counter < wait_size){
                waitroom[wait_counter]=females_q[0];
                wait_counter++;
                delete_one_F_queue(0);
                for(int i=0;i<size_counter;i++){
                    if (initial_person_shm[i].MF == 'F'){
                        females_q[females_counter]=initial_person_shm[i].id;
                        removed_id[size_rem]=i;
                        size_rem++;
                        //kill(females_q[females_counter],SIGUSR1);
                        females_counter++;
                        break;
                        } 
                    }
                    //kill(females_q[females_counter-1],SIGUSR1); 
                } 
            }
            else if ( males_counter > 0 && wait_counter < wait_size){
            kill(males_q[0],SIGUSR2);
            sleep(1);
            close_sem(semid_comms);
            int xy = comms[0];
            open_sem(semid_comms);
            printf("id = %d, permit = %d\n",males_q[0],xy);
            fflush(stdout);
            if(wait_counter < wait_size){
                waitroom[wait_counter]=males_q[0];
                wait_counter++;
                delete_one_M_queue(0);
                for(int i=0;i<size_counter;i++){
                    if (initial_person_shm[i].MF == 'M'){
                        males_q[males_counter]=initial_person_shm[i].id;
                        removed_id[size_rem]=i;
                        size_rem++;
                        //kill(males_q[males_counter],SIGUSR1);
                        males_counter++;
                        break;
                        } 
                    }
                    //kill(males_q[males_counter-1],SIGUSR1); 
                }
            }
            else{
                printf("queues are empty or wait room is full\n");
                break;
            }
        }
        remove_alot_initial_queue();
        size[0]=size_counter;
        size[1]=females_counter;
        size[2]=males_counter;
        size[3]=wait_counter;
        open_sem(semid_person);
        open_sem(semid_size);
        open_sem(semid_males);
        open_sem(semid_females);
        open_sem(semid_wait);
        sleep(2);
        //printf("weell\n");
        flag=0;
        
    }

    }
}


void add_to_queue(){

    for( int i = 0; i < size_counter; i++){
    printf("in exec whoile people[%d] => id = %d, gender = %c, permit = %d\n",i,initial_person_shm[i].id,initial_person_shm[i].MF,initial_person_shm[i].permit);
    fflush(stdout);
    if (initial_person_shm[i].MF == 'F'){
        if(females_counter < a[7]){
            females_q[females_counter]=initial_person_shm[i].id;
            removed_id[size_rem]=i;
            size_rem++;
            //kill(females_q[females_counter],SIGUSR1);
            females_counter++;
            }
        }
    else{
        if(males_counter < a[7]){
            males_q[males_counter]=initial_person_shm[i].id;
            removed_id[size_rem]=i;
            size_rem++;
            //kill(males_q[males_counter],SIGUSR1);
            males_counter++;
            } 
        }      
    }
    for(int i=0; i<size_rem; i++){
        printf("id=%d, %d\n",removed_id[i],initial_person_shm[removed_id[i]].id);
    }
}

void remove_alot_initial_queue(){
    
    for (int i=0;i<size_rem;i++){
        delete_one_initial_queue(removed_id[i]-i);
        removed_id[i]=0;
    }
    size_rem=0;
}

void delete_one_M_queue(int pos){

    //printf("\n\nremove person in position %d\n\n",pos);
    for (int i = pos; i < males_counter-1; i++) {
        males_q[i] = males_q[i + 1];
    }
    males_q[males_counter-1] = 0;
    // Decrease the size of the array
    males_counter--;
}

void delete_one_F_queue(int pos){

    //printf("\n\nremove person in position %d\n\n",pos);
    for (int i = pos; i < females_counter-1; i++) {
        females_q[i] = females_q[i + 1];
    }
    females_q[females_counter-1] = 0;
    // Decrease the size of the array
    females_counter--;
}

void delete_one_initial_queue(int pos){

    //printf("\n\nremove person in position %d\n\n",pos);
    for (int i = pos; i < size_counter-1; i++) {
        initial_person_shm[i] = initial_person_shm[i + 1];
    }
    initial_person_shm[size_counter-1].id = 0;
    initial_person_shm[size_counter-1].MF = '0';
    initial_person_shm[size_counter-1].permit = 0;
    // Decrease the size of the array
    size_counter--;
}

void sigset_catcherA(int n)
{
    flag = 1;
}

