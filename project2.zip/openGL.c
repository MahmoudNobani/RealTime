#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <unistd.h>
#include <time.h>
#include "local.h"
int shmid_size, sem_size,shmid_thresh,sem_thresh;
int *size,*thresh;
int prev=0,prev1=0;
key_t ipc_key;
//gcc -g openGL.c -o openGL -lglut -lGLU -lGL -lm


void clearDotsRight(int n) {
    int m=0;
    float x;
    for(float i = 0.4 ; i < 0.9; i+=0.1){//x
        for(float j = -0.8; j < 0.9; j+=0.1){//y
            glPointSize(10.0f);
            glBegin(GL_POINTS);
            glColor3f(0.0f, 0.0f, 0.0f); // Whited
            x=i*-1;
            glVertex2f(x, j); //x,y
            glEnd();
            m++;
            if(m>=n){
                return;
            }

        }
    }
    glFlush();

}

void clearDotsLeft(int n) {
    int m=0;
    float x;
    for(float i = 0.7 ; i > 0.5; i-=0.1){//x
        for(float j = -0.6; j < 0.7; j+=0.1){//y
            glPointSize(10.0f);
            glBegin(GL_POINTS);
            glColor3f(0.0f, 0.0f, 0.0f); // Whited
            //x=j*-1;
            glVertex2f(i, j); //x,y
            glEnd();
            m++;
            if(m>=n){
                return;
            }

        }
    }
    glFlush();

}


void addDotsRight(int n) {
    clearDotsRight(prev);
    int m=0;
    float x;
    for(float i = 0.4 ; i < 0.9; i+=0.1){//x
        for(float j = -0.8; j < 0.9; j+=0.1){//y
            glPointSize(10.0f);
            glBegin(GL_POINTS);
            glColor3f(1.0f, 1.0f, 1.0f); // Whited
            x=i*-1;
            glVertex2f(x, j); //x,y
            glEnd();
            m++;
            if(m>=n){
                return;
            }

        }
    }
    prev=n;
 glFlush();
}

void addDotsLeft(int n) {
    clearDotsLeft(prev1);
    int m=0;
    float x;

    for(float i = 0.7 ; i > 0.5; i-=0.1){//x
        for(float j = -0.6; j < 0.7; j+=0.1){//y
            glPointSize(10.0f);
            glBegin(GL_POINTS);
            glColor3f(1.0f, 1.0f, 1.0f); // Whited
            //x=j*-1;
            glVertex2f(i, j); //x,y
            glEnd();
            m++;
            if(m>=n){
                return;
            }

        }
    }
    prev1=n;
    glFlush();
}


void progress_bar1(float p){
    // Draw the first progress bar
    glColor3f(0.0, 1.0, 0.0);
    glBegin(GL_QUADS);
        glVertex2f(-0.2, 0.425);
        glVertex2f(-0.2 + p, 0.425);
        glVertex2f(-0.2 + p, 0.325);
        glVertex2f(-0.2, 0.325);
    glEnd();
}


void progress_bar2(float p){
    // Set the color of the second progress bar to blue
    glColor3f(0.0, 0.0, 1.0);

    // Draw the second progress bar
    glBegin(GL_QUADS);
        glVertex2f(-0.2, -0.425);
        glVertex2f(-0.2 + p, -0.425);
        glVertex2f(-0.2 + p, -0.325);
        glVertex2f(-0.2, -0.325);
    glEnd();
}

void progress_bar3(float p){
        // Set the color of the second progress bar to black
    glColor3f(0.0, 0.0, 0.0);


            // Draw the third rectangle
    glBegin(GL_QUADS);
        glVertex2f(-0.8+0.05,0.975);
        glVertex2f(-0.8+0.05+p, 0.975);
        glVertex2f(-0.8+0.05+p, 0.925);
        glVertex2f(-0.8+0.05, 0.925);
    glEnd();
}

void progress_bar4(float p){
    // Set the color of the second progress bar to purple
    glColor3f(1.0, 0.0, 1.0);


    // Draw the second progress bar
    glBegin(GL_QUADS);
        glVertex2f(-0.2+0.05,0.975);
        glVertex2f(-0.2+0.05+p, 0.975);
        glVertex2f(-0.2+0.05+p, 0.925);
        glVertex2f(-0.2+0.05, 0.925);
    glEnd();
}

void progress_bar5(float p){
    // Set the color of the second progress bar to yellow
    glColor3f(1.0, 1.0, 0.0);


    // Draw the second progress bar
    glBegin(GL_QUADS);
        glVertex2f(0.4+0.05,0.975);
        glVertex2f(0.4+0.05+p, 0.975);
        glVertex2f(0.4+0.05+p, 0.925);
        glVertex2f(0.4+0.05, 0.925);
    glEnd();
}


void drawPageFrame() {  //here  put these inside the drawPageFrame(float progress1, float progress2){
	//and insted of 0.4 write the variables progress1 and the second 0.4 replace it with progress2 
    // Set the color of the frame to blue
    glColor3f(0.0, 0.0, 1.0);

    // Draw the top and bottom sides of the frame
    glBegin(GL_QUADS);
        glVertex2f(-1.0, 1.0);
        glVertex2f(1.0, 1.0);
        glVertex2f(1.0, 0.9);
        glVertex2f(-1.0, 0.9);

        glVertex2f(-1.0, -1.0);
        glVertex2f(1.0, -1.0);
        glVertex2f(1.0, -0.9);
        glVertex2f(-1.0, -0.9);
    glEnd();

    // Draw the left and right sides of the frame
    glBegin(GL_QUADS);
        glVertex2f(-1.0, 1.0);
        glVertex2f(-0.9, 1.0);
        glVertex2f(-0.9, -1.0);
       glVertex2f(-1.0, -1.0);

        glVertex2f(1.0, 1.0);
        glVertex2f(0.9, 1.0);
        glVertex2f(0.9, -1.0);
        glVertex2f(1.0, -1.0);
    glEnd();
    glColor3f(0.0, 1.0, 0.0);

    glColor3f(1.0, 0.0, 0.0);

    // Draw the first line
   // glBegin(GL_LINES);
        //glVertex2f(-0.8, 0.8);
      //  glVertex2f(0.5, 0.8);
    //glEnd();

    // Draw the second line
   // glBegin(GL_LINES);
        //glVertex2f(-0.8, 0.7);
      //  glVertex2f(0.5, 0.7);
    //glEnd();
    //
    //Draw the horizntal line between the progress bars
    glColor3f(1.0, 0.0, 0.0);

    // Draw the line
    glBegin(GL_LINES);
        glVertex2f(-0.3, 0.0);
        glVertex2f(0.3, 0.0);
    glEnd();
//draw the vertical lines 
    glColor3f(1.0, 0.0, 0.0);

    // Draw the first line
    glBegin(GL_LINES);
        glVertex2f(-0.3, 0.8);
        glVertex2f(-0.3, -0.8);
    glEnd();

    // Draw the second line
  glBegin(GL_LINES);
        glVertex2f(0.3, 0.8);
        glVertex2f(0.3, -0.8);
    glEnd();

    //*******************Draw two rectangels**********************
    // Set the color of the lines to red
    glColor3f(1.0, 0.0, 0.0);

    // Draw the first rectangle
    glBegin(GL_LINE_LOOP);
        glVertex2f(-0.2, 0.425);
        glVertex2f(0.3, 0.425);
        glVertex2f(0.3, 0.325);
        glVertex2f(-0.2, 0.325);
    glEnd();

    // Draw the second rectangle
    glBegin(GL_LINE_LOOP);
        glVertex2f(-0.2,-0.425);
        glVertex2f(0.3, -0.425);
        glVertex2f(0.3, -0.325);
        glVertex2f(-0.2, -0.325);
    glEnd();

    glBegin(GL_LINE_LOOP);
        glVertex2f(-0.8+0.05,0.975);
        glVertex2f(-0.5+0.05, 0.975);
        glVertex2f(-0.5+0.05, 0.925);
        glVertex2f(-0.8+0.05, 0.925);
    glEnd();


            // Draw the 4rth rectangle
    glBegin(GL_LINE_LOOP);
        glVertex2f(-0.2+0.05,0.975);
        glVertex2f(0.1+0.05, 0.975);
        glVertex2f(0.1+0.05, 0.925);
        glVertex2f(-0.2+0.05, 0.925);
    glEnd();

            // Draw the fifth rectangle
    glBegin(GL_LINE_LOOP);
        glVertex2f(0.4+0.05,0.975);
        glVertex2f(0.7+0.05, 0.975);
        glVertex2f(0.7+0.05, 0.925);
        glVertex2f(0.4+0.05, 0.925);
    glEnd();

    //*******************draw table***********************
       glColor3f(0.6, 0.4, 0.2);

    // Draw the tabletop
      // Set the color of the line to red
    glColor3f(1.0, 0.0, 0.0);

    // Draw vertical  line at most right
    glBegin(GL_LINES);
        glVertex2f(0.8, 0.5);
        glVertex2f(0.8, -0.5);
    glEnd();

    //draw vertical line with two horizantal lines at most right
    glBegin(GL_LINES);
        glVertex2f(0.5, 0.5);
        glVertex2f(0.5, -0.5);
    glEnd();
    //draw the two horizantal lines at the most right
     // Set the color of the lines to red
    glColor3f(1.0, 0.0, 0.0);

    // Draw the first line
    glBegin(GL_LINES);
        glVertex2f(0.35, 0.5);
        glVertex2f(0.5, 0.5);
    glEnd();

    // Draw the second line
    glBegin(GL_LINES);
        glVertex2f(0.35, -0.5);
        glVertex2f(0.5, -0.5);
    glEnd();


    srand(time(NULL));
    int k = size[0]%86;
    addDotsRight(k);

    int z = size[3]%26;
    addDotsLeft(z);

    float p1 = ((float)size[1]/a[7])*0.5;
    progress_bar1(p1);

    float p2 = ((float)size[2]/a[7])*0.5;
    progress_bar2(p2);

    float p3 = ((float)thresh[0]/a[0])*0.3;
    progress_bar3(p3);

    float p4 = ((float)thresh[1]/a[1])*0.3;
    progress_bar4(p4);

    float p5 = ((float)thresh[2]/a[2])*0.3;
    progress_bar5(p5);



    glFlush();


}



//**********************add dots to the most right*********************




//************************* remove dots********************************

/* Handler for window re-size event. Called back when the window first appears and
   whenever the window is re-sized with its new width and height */
void reshape(GLsizei width, GLsizei height) {  // GLsizei for non-negative integer
   // Compute aspect ratio of the new window
   if (height == 0) height = 1;                // To prevent divide by 0
   GLfloat aspect = (GLfloat)width / (GLfloat)height;
 
   // Set the viewport to cover the new window
   glViewport(0, 0, width, height);
 
   // Set the aspect ratio of the clipping area to match the viewport
   glMatrixMode(GL_PROJECTION);  // To operate on the Projection matrix
   glLoadIdentity();
   if (width >= height) {
     // aspect >= 1, set the height from -1 to 1, with larger width
      gluOrtho2D(-1.0 * aspect, 1.0 * aspect, -1.0, 1.0);
   } else {
      // aspect < 1, set the width to -1 to 1, with larger height
     gluOrtho2D(-1.0, 1.0, -1.0 / aspect, 1.0 / aspect);
   }
}

//end the remove dots **************************************************
void display() {

    glClear(GL_COLOR_BUFFER_BIT);

    // Draw the page frame
    drawPageFrame();

 

    // Swap the buffers to update the display
    glutSwapBuffers();
    sleep(2);
    glutPostRedisplay();
    // Clear the window

}
//*************************************remove function********************


//***********************end of remove function*********************
int main(int argc, char** argv) {

    read_param();

    ipc_key = ftok(".", 'S');
    if ( (shmid_size = shmget(ipc_key, 0, 0)) < 0 ) {
        perror("shmget fail for size in officer");
        exit(1);
    }

    if ( (size = (int *) shmat(shmid_size, 0, 0)) == (int *) -1 ) {
        perror("shmat: attach for size in officer");
        exit(2);
    }

    ipc_key = ftok(".", 'S');
    //printf("officer ipc_key:%d\n", ipc_key);
    int semid_size = semget(ipc_key, 1, 0);  // Attach to the semaphore set  
    if (semid_size == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }



    //make shared memory for the the threshhold counter used
    ipc_key = ftok(".", 'T');
    if ( (shmid_thresh = shmget(ipc_key, 0, IPC_CREAT | 0666)) < 0 ) {
        perror("shmget fail for person threshold");
        exit(1);
    }

    if ( (thresh = (int *) shmat(shmid_thresh, 0, 0)) == (int *) -1 ) {
        perror("shmat: for person threshold");
        exit(2);
    }


    // create a semaphore for thresholds shm
    ipc_key = ftok(".", 'T');
    int semid_thresh = semget(ipc_key, 1, 0);  // Attach to the semaphore set  
    if (semid_thresh == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }
    //printf("officer semid_size=%d\n",semid_size);
    // Initialize GLUT
    glutInit(&argc, argv);

    // Set the window size and position
   
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
  

    // Set the display mode to double buffering
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

    // Create the window
    glutCreateWindow("OIM");
    // Set the display callback function
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);

    // Enter the GLUT event loop
    glutMainLoop();
    sleep(2);
    addDotsRight(40);
    sleep(2);
    addDotsRight(10);
    sleep(2);


    return 0;
}
