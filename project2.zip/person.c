#include "local.h"

char gender;
int permit;
int max = 10;
int removed_id,size_rem=0;
int flag=0;
int wait_size,wait_counter;
int x=1000000000;
int patiance;
void delete_one_wait_queue(int);

int main(int argc, char *argv[ ])
{
  
  void sigset_catcherA(int);
  void sigset_catcherB(int);

  sigset(SIGUSR1, sigset_catcherA);
  sigset(SIGUSR2, sigset_catcherB);

  srand((unsigned) time(&t) + getpid());
  patiance = rand()%4+3;

      initial = current_time();
      sleep(1);
    //printf("initial time = %ld\n", initial);

    read_param();
    int males[a[7]],females[a[7]];
    wait_size=a[8];
    //make shared memory for the the different sizes used
    ipc_key = ftok(".", 'S');
    if ( (shmid_size = shmget(ipc_key, 0, 0)) < 0 ) {
        perror("shmget fail for size in officer");
        exit(1);
    }

    if ( (size = (int *) shmat(shmid_size, 0, 0)) == (int *) -1 ) {
        perror("shmat: attach for size in officer");
        exit(2);
    }

    //make shared memory for the person first queue
    ipc_key = ftok(".", 14369);
    if ( (shmid_person = shmget(ipc_key, 0, 0)) < 0 ) {
        perror("shmget for person in officer");
        exit(1);
    }

    if ( (initial_person_shm = (struct person *) shmat(shmid_person, 0, 0)) == (struct person *) -1 ) {
        perror("shmat attach for person in officer ");
        exit(2);
    }
    //make shared memory for the the different comms used
    ipc_key = ftok(".", 'W');
    if ( (shmid_wait = shmget(ipc_key, 0, IPC_CREAT | 0666)) < 0 ) {
        perror("shmget fail for real wait");
        exit(1);
    }

    if ( (waitroom = (int *) shmat(shmid_wait, 0, 0)) == (int *) -1 ) {
        perror("shmat: for real wait");
        exit(2);
    }




    //make shared memory for the the threshhold counter used
    ipc_key = ftok(".", 'T');
    if ( (shmid_thresh = shmget(ipc_key, 0, IPC_CREAT | 0666)) < 0 ) {
        perror("shmget fail for person threshold");
        exit(1);
    }

    if ( (thresh = (int *) shmat(shmid_thresh, 0, 0)) == (int *) -1 ) {
        perror("shmat: for person threshold");
        exit(2);
    }
    
    //build males queue:
    ipc_key = ftok(".", 'M');
    if ( (shmid_males = shmget(ipc_key, 0, IPC_CREAT | 0666)) < 0 ) {
        perror("shmget fail for officer male queue");
        exit(1);
    }

    if ( (males_q = (int *) shmat(shmid_males, 0, 0)) == (int *) -1 ) {
        perror("shmat: parent attach for officer male queue");
        exit(2);
    }

    //build females:
    ipc_key = ftok(".", 'F');
    if ( (shmid_females = shmget(ipc_key, 0, IPC_CREAT | 0666)) < 0 ) {
        perror("shmget fail for officer female queue");
        exit(1);
    }

    if ( (females_q = (int *) shmat(shmid_females, 0, 0)) == (int *) -1 ) {
        perror("shmat: parent attach for officer female queue");
        exit(2);
    }


    // create a semaphore for comms shm
    ipc_key = ftok(".", 'C');
    int semid_comms = semget(ipc_key, 1, 0);  // Attach to the semaphore set  
    if (semid_comms == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }


    // create a semaphore for wait shm
    ipc_key = ftok(".", 'W');
    int semid_wait = semget(ipc_key, 1, 0);  // Attach to the semaphore set  
    if (semid_wait == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }


    // create a semaphore for thresholds shm
    ipc_key = ftok(".", 'T');
    int semid_thresh = semget(ipc_key, 1, 0);  // Attach to the semaphore set  
    if (semid_thresh == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }


    ipc_key = ftok(".", 'S');
    //printf("officer ipc_key:%d\n", ipc_key);
    int semid_size = semget(ipc_key, 1, 0);  // Attach to the semaphore set  
    if (semid_size == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }
    //printf("officer semid_size=%d\n",semid_size);

    ipc_key = ftok(".", 14369);
    int semid_person = semget(ipc_key, 1, 0);  // Attach to the semaphore set  
    if (semid_person == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }
    //printf("semid_person=%d\n",semid_person);

    // create a semaphore for males shm
    ipc_key = ftok(".", 'M');
    int semid_males = semget(ipc_key, 1, 0);  // Attach to the semaphore set
    if (semid_males == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }

    // create a semaphore for females shm
    ipc_key = ftok(".", 'F');
    int semid_females = semget(ipc_key, 1, 0);  // Attach to the semaphore set
    if (semid_females == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }

  permit = atoi(argv[1]);
  int x = atoi(argv[2]);
  if (x==0){
    gender = 'M';
  }
  else{
    gender = 'F';
  }

  printf("in exec2 id = %d, gender %c, permit = %d\n",getpid(), gender, permit);
  fflush(stdout);

  while (1){
  //   if( (int) current_time() >= initial+20){
  //   srand((unsigned) time(&t) + getpid());
  //   int y = (int) ((flag+1)*patiance*x)/( (int) current_time()-initial);
  //   int probiblty = (int) (rand()%y); //calculate rand
  //   if( probiblty <= 1 ){
  //     printf("pid = %d is out\n",getpid());
  //     if(flag == 1){
  //       close_sem(semid_person);
  //       close_sem(semid_size);
  //       //printf("pid = %d is out\n",getpid());
  //         for (int i = 0; i < size[0]; i++) {
  //             if ( initial_person_shm[i].id == getpid()){
  //               if(i == size[0]-1){
  //                 initial_person_shm[size[0]-1].id = 0;
  //                 initial_person_shm[size[0]-1].MF = '0';
  //                 initial_person_shm[size[0]-1].permit = 0;
  //                 break;
  //               }
  //               else{
  //                 for(int j = i; j < size[0]-1; j++){
  //                   initial_person_shm[j] = initial_person_shm[j + 1];
  //                 }
  //                 initial_person_shm[size[0]-1].id = 0;
  //                 initial_person_shm[size[0]-1].MF = '0';
  //                 initial_person_shm[size[0]-1].permit = 0;
  //                 break;
  //               }
  //             }
  //         }
  //         // Decrease the size of the array
  //         size[0]--;

  //       open_sem(semid_person);
  //       open_sem(semid_size);

  //     }
  //     if(flag == 2){
  //       if (gender = 'M'){
  //         close_sem(semid_person);
  //         close_sem(semid_size);
  //         close_sem(semid_males);
  //         //remove from Males queue
  //         for (int i = 0; i < size[2]; i++) {
  //             if ( males_q[i] == getpid()){
  //               if(i == size[2]-1){
  //                 males_q[size[2]-1] = 0;
  //                 break;
  //               }
  //               else{
  //                 for(int j = i; j < size[2]-1; j++){
  //                   males_q[j] = males_q[j + 1];
  //                 }
  //                 males_q[size[2]-1] = 0;
  //                 break;
  //               }
  //             }
  //         }
  //         size[2]--;
  //         //add another one
  //         for(int i=0;i<size[0];i++){
  //           if (initial_person_shm[i].MF == 'M'){
  //               males_q[size[2]-1]=initial_person_shm[i].id;
  //               removed_id=i;
  //               size_rem++;
  //               size[2]++;
  //               break;
  //               } 
  //           }
  //           //remove from outter queue
  //         for (int i = removed_id; i < size[0]-1; i++) {
  //             initial_person_shm[i] = initial_person_shm[i + 1];}
  //             initial_person_shm[size[0]-1].id = 0;
  //             initial_person_shm[size[0]-1].MF = '0';
  //             initial_person_shm[size[0]-1].permit = 0;
  //             // Decrease the size of the array
  //             size[0]--;
  //         open_sem(semid_person);
  //         open_sem(semid_size);
  //         open_sem(semid_males);

  //       }
  //       else if (gender == 'F'){

  //         close_sem(semid_person);
  //         close_sem(semid_size);
  //         close_sem(semid_females);
  //         //remove from feMales queue
  //         for (int i = 0; i < size[1]; i++) {
  //             if ( females_q[i] == getpid()){
  //               if(i == size[2]-1){
  //                 females_q[size[1]-1] = 0;
  //                 break;
  //               }
  //               else{
  //                 for(int j = i; j < size[1]-1; j++){
  //                   females_q[j] = females_q[j + 1];
  //                 }
  //                 males_q[size[1]-1] = 0;
  //                 break;
  //               }
  //             }
  //         }
  //         size[1]--;
  //         //add another one
  //         for(int i=0;i<size[0];i++){
  //           if (initial_person_shm[i].MF == 'F'){
  //               females_q[size[1]-1]=initial_person_shm[i].id;
  //               removed_id=i;
  //               size_rem++;
  //               size[1]++;
  //               break;
  //               } 
  //           }
  //           //remove from outter queue
  //         for (int i = removed_id; i < size[0]-1; i++) {
  //             initial_person_shm[i] = initial_person_shm[i + 1];}
  //             initial_person_shm[size[0]-1].id = 0;
  //             initial_person_shm[size[0]-1].MF = '0';
  //             initial_person_shm[size[0]-1].permit = 0;
  //             // Decrease the size of the array
  //             size[0]--;
  //         open_sem(semid_person);
  //         open_sem(semid_size);
  //         open_sem(semid_males);

  //       }
  //     }
  //     if(flag == 3){
  //       close_sem(semid_size);
  //       close_sem(semid_wait);
  //       wait_counter=size[3];
  //       int pos = -1;
  //       for (int i = 0; i < wait_counter; i++) {
  //           if(getpid() == waitroom[i]){
  //             pos = i;
  //           }
  //       }
  //       if(pos != -1){
  //         delete_one_wait_queue(pos);
  //       }
  //       size[3]=wait_counter;

  //       open_sem(semid_size);
  //       open_sem(semid_wait);
  //     }
  //     exit(0);
  //   }
   
  //  initial= (int)current_time()+20;
  //   }
   }

}

void delete_one_wait_queue(int pos){

    //printf("\n\nremove person in position %d\n\n",pos);
    for (int i = pos; i < wait_counter-1; i++) {
        waitroom[i] = waitroom[i + 1];
    }
    waitroom[wait_counter-1] = 0;
    // Decrease the size of the array
    wait_counter--;
}

void sigset_catcherA(int n)
{
  flag++;
}

void sigset_catcherB(int n)
{
  //printf("in sig user of person\n");

      //make shared memory for the the different comms used
    ipc_key = ftok(".", 'C');
    if ( (shmid_comms = shmget(ipc_key, 0, IPC_CREAT | 0666)) < 0 ) {
        perror("shmget fail for person comms");
        exit(1);
    }

    if ( (comms = (int *) shmat(shmid_comms, 0, 0)) == (int *) -1 ) {
        perror("shmat: for person comms");
        exit(2);
    }
    // create a semaphore for comms shm
    ipc_key = ftok(".", 'C');
    int semid_comms = semget(ipc_key, 1, 0);  // Attach to the semaphore set  
    if (semid_comms == -1)
    {
        if (errno != 0)
        {
            perror("semget");
            exit(1);
        }
        
    }

  close_sem(semid_comms);
  comms[0]=permit;
  //printf("perimt is %d, comms %d,of id %d, inside person\n",permit,comms[0],getpid());
  fflush(stdout);
  open_sem(semid_comms);
}